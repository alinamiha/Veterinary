<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');



// **********************************************************************//
// ! WooCommerce PRODUCT slider and grid
// **********************************************************************//

if ( ! function_exists( 'etheme_products_shortcodes' ) ):

	if( class_exists('Vc_Vendor_Woocommerce') ) {
		$Vc_Vendor_Woocommerce = new Vc_Vendor_Woocommerce();
		add_filter( 'vc_autocomplete_etheme_products_ids_callback', array($Vc_Vendor_Woocommerce, 'productIdAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_etheme_products_ids_render', array($Vc_Vendor_Woocommerce, 'productIdAutocompleteRender',), 10, 1 );
	}

	function etheme_products_shortcodes($atts, $content=null){
	    global $wpdb, $woocommerce_loop;
	    if ( !class_exists('Woocommerce') ) return false;

	    extract(shortcode_atts(array(
	        'ids' => '',
	        'skus' => '',
	        'columns' => 4,
	        'shop_link' => 1,
	        'limit' => 20,
	        'block_id' => false,
	        'product_img_hover' => '',
	        'type' => 'slider',
	        'style' => 'default',
	        'products' => '', //featured new sale bestsellings recently_viewed
	        'title' => '',
	        'desktop' => 4,
	        'notebook' => 4,
	        'tablet' => 3,
	        'phones' => 1,
	        'outofstock' => 0,
	        'orderby' => 'ASC',
	        'order' => 'default',
	        'categories' => ''
	    ), $atts));


		if (!empty($ids) && $order == 'post__in') {
			$order = 'post__in';
		} elseif ($order == 'post__in') {
			$order = 'ID';
		} elseif($order == 'default') {
			$order = '';
		} else {
			$order = $order;
		}

	    $args = array(
	        'post_type'             => 'product',
	        'ignore_sticky_posts'   => 1,
	        'no_found_rows'         => 1,
	        'posts_per_page'        => $limit,
	        'orderby'   => $order,
	        'order'     => $orderby,
	        'meta_query'     => array()
	    );

	    $args['tax_query'][] = array(
	        'taxonomy' => 'product_visibility',
	        'field'    => 'name',
	        'terms'    => 'hidden',
	        'operator' => 'NOT IN',
	    );

	    if ( $products == 'featured' ) {
			$args['tax_query'][] = array(
			  'taxonomy' => 'product_visibility',
			  'field'    => 'name',
			  'terms'    => 'featured',
			  'operator' => 'IN',
			);
	    }

	    if ($products == 'new') {
	        $args['meta_key'] = 'product_new';
	        $args['meta_value'] = 'enable';
	    }

	    if ($products == 'sale') {
	        $product_ids_on_sale = wc_get_product_ids_on_sale();
	        $args['post__in'] = array_merge( array( 0 ), $product_ids_on_sale );
	    }

	    if ($products == 'bestsellings') {
	        $args['meta_key'] = 'total_sales';
	        $args['orderby'] = 'meta_value_num';
	    }

	    if ($products == 'recently_viewed') {
	        $viewed_products = ! empty( $_COOKIE['woocommerce_recently_viewed'] ) ? (array) explode( '|', $_COOKIE['woocommerce_recently_viewed'] ) : array();
	        $viewed_products = array_filter( array_map( 'absint', $viewed_products ) );
	        if ( empty( $viewed_products ) )
	          return;
	        $args['post__in'] = array_reverse( $viewed_products );
	        $args['orderby'] = 'rand';
	    }


	    if($skus != ''){
	        $skus = explode(',', $atts['skus']);
	        $skus = array_map('trim', $skus);
	        $args['meta_query'][] = array(
	            'key'       => '_sku',
	            'value'     => $skus,
	            'compare'   => 'IN'
	        );
	    }

	    if($ids != ''){
	        $ids = explode(',', $atts['ids']);
	        $ids = array_map('trim', $ids);
	        $args['post__in'] = $ids;
	    }

	    // Narrow by categories
	    if ( $categories != '' ) {
	      $categories = explode(",", $categories);
	      $gc = array();
	      foreach ( $categories as $grid_cat ) {
	          array_push($gc, $grid_cat);
	      }
	      $gc = implode(",", $gc);
	      ////http://snipplr.com/view/17434/wordpress-get-category-slug/
	      //$args['category_name'] = $gc;
	      $pt = array('product');

		  $args['tax_query'][] = array(
		  	'relation' => 'OR',
		  	array(
		      'taxonomy' => 'product_tag',
		      'terms' => $categories,
		      'operator' => 'IN',
		      ),
		  	array(
		      'taxonomy' => 'product_cat',
		      'terms' => $categories,
		      'operator' => 'IN',
		      )
		  );
	      // $taxonomies = get_taxonomies('', 'object');
	      // $args['tax_query'] = array('relation' => 'OR');
	      // foreach ( $taxonomies as $t ) {
	      //     if ( in_array($t->object_type[0], $pt) ) {
	      //         $args['tax_query'][] = array(
	      //             'taxonomy' => $t->name,//$t->name,//'portfolio_category',
	      //             'terms' => $categories,
	      //             'field' => 'id',
	      //         );
	      //     }
	      // }


	    }

	    $customItems = array(
	        'desktop' => $desktop,
	        'notebook' => $notebook,
	        'tablet' => $tablet,
	        'phones' => $phones
	    );

	    $woocommerce_loop['hover'] = $product_img_hover;

	     if ($outofstock) {
		    $args['meta_query'][] = array (
		    	 'key'       => '_stock_status',
		        'value'     => 'outofstock',
		        'compare'   => 'NOT IN'
		    );
		}

	    if ($type == 'slider') {
	    	$slider_args = array(
	    		'title' => $title,
	    		'shop_link' => $shop_link,
	    		'slider_type' => false,
	    		'items' => $customItems,
	    		'style' => $style,
	    	);
	        ob_start();
	        etheme_create_slider($args, $slider_args);
	        $output = ob_get_contents();
	        ob_end_clean();
	    } elseif($type == 'full-width') {
	    	$slider_args = array(
	    		'title' => $title,
	    		'shop_link' => $shop_link,
	    		'slider_type' => 'swiper',
	    		'customItems' => $customItems,
	    		'style' => $style,
	    		'block_id' => $block_id
	    	);
	        ob_start();
	        etheme_create_slider($args, $slider_args);
	        $output = ob_get_contents();
	        ob_end_clean();
	    } else {
	        $woocommerce_loop['view_mode'] = $type;
	        $output = etheme_products($args, $title, $columns);
	    }

	    unset($woocommerce_loop['hover']);

	    return $output;

	}

endif;




// **********************************************************************//
// ! Register New Element: Products
// **********************************************************************//

if ( function_exists('vc_map') ) {

	$static_blocks = array('--choose--' => '');

	foreach(et_get_static_blocks() as $value) {
	    $static_blocks[$value['label']] = $value['value'];
	}

	$fpost_params = array(
	  'name' => 'Products',
	  'base' => 'etheme_products',
	  'icon' => 'icon-wpb-etheme',
	  'category' => 'Eight Theme',
	  'params' => array(
	    array(
	      "type" => "textfield",
	      "heading" => esc_html__("Title", 'woopress-core'),
	      "param_name" => "title"
	    ),
	    array(
	      'type' => 'autocomplete',
	      "heading" => esc_html__("IDs", 'woopress-core'),
	      "param_name" => "ids",
		  'settings' => array(
			  'multiple' => true,
			  'sortable' => true,
			  'unique_values' => true,
			  // In UI show results except selected. NB! You should manually check values in backend
		  ),
		  'save_always' => true,
	    ),
	    array(
	      "type" => "textfield",
	      "heading" => esc_html__("SKUs", 'woopress-core'),
	      "param_name" => "skus"
	    ),
	   	array(
	      "type" => "dropdown",
	      "heading" => esc_html__("Order by", 'woopress-core'),
	      "param_name" => "order",
	      "value" => array(
	      	esc_html__("Default", 'woopress-core') => 'default',
	      	esc_html__("Date", 'woopress-core') => 'date',
	      	esc_html__("Comments", 'woopress-core') => 'comment_count',
	      	esc_html__("Title", 'woopress-core') => 'title',
	      	esc_html__("ID", 'woopress-core') => 'ID',
	      	esc_html__('Custom Order', 'woopress-core') => 'postesc_html__in',
	      	esc_html__("Rand", 'woopress-core') => 'rand',
	      )
	    ),
	    array(
	      "type" => "dropdown",
	      "heading" => esc_html__("Sort order", 'woopress-core'),
	      "param_name" => "orderby",
	      "value" => array(
	      	esc_html__("Ascending", 'woopress-core') => 'ASC',
	      	esc_html__("Descending", 'woopress-core') => 'DESC',
	      )
	    ),
	    array(
	      "type" => "dropdown",
	      "heading" => esc_html__("Hover effect", 'woopress-core'),
	      "param_name" => "product_img_hover",
	      "value" => array(
	      	'' => '',
	      	esc_html__("Disable", 'woopress-core') => 'disable',
	      	esc_html__("Swap", 'woopress-core') => 'swap',
	      	esc_html__("Images Slider", 'woopress-core') => 'slider',
	      	esc_html__("Mask with information", 'woopress-core') => 'mask',
	      )
	    ),
	    array(
	      "type" => "dropdown",
	      "heading" => esc_html__("Display Type", 'woopress-core'),
	      "param_name" => "type",
	      "value" => array( esc_html__("Slider", 'woopress-core') => 'slider',esc_html__("Slider full width (LOOK BOOK)", 'woopress-core') => 'full-width', esc_html__("Grid", 'woopress-core') => 'grid', esc_html__("List", 'woopress-core') => 'list')
	    ),
	    array(
	      "type" => "dropdown",
	      "dependency" => Array('element' => "type", 'value' => array('full-width')),
	      "heading" => esc_html__("Static block for the first slide of the LOOK BOOK", 'woopress-core'),
	      "param_name" => "block_id",
	      "value" => $static_blocks
	    ),
	    array(
	      "type" => "textfield",
	      "heading" => esc_html__("Columns", 'woopress-core'),
	      "param_name" => "columns",
	      "dependency" => Array('element' => "type", 'value' => array('grid'))
	    ),
	    array(
	      "type" => "dropdown",
	      "heading" => esc_html__("Product view", 'woopress-core'),
	      "param_name" => "style",
	      "dependency" => Array('element' => "type", 'value' => array('slider')),
	      "value" => array( esc_html__("Default", 'woopress-core') => 'default', esc_html__("Advanced", 'woopress-core') => 'advanced')
	    ),
	    array(
	      "type" => "textfield",
	      "heading" => esc_html__("Number of items on desktop", 'woopress-core'),
	      "param_name" => "desktop",
	      "dependency" => Array('element' => "type", 'value' => array('slider'))
	    ),
	    array(
	      "type" => "textfield",
	      "heading" => esc_html__("Number of items on notebook", 'woopress-core'),
	      "param_name" => "notebook",
	      "dependency" => Array('element' => "type", 'value' => array('slider'))
	    ),
	    array(
	      "type" => "textfield",
	      "heading" => esc_html__("Number of items on tablet", 'woopress-core'),
	      "param_name" => "tablet",
	      "dependency" => Array('element' => "type", 'value' => array('slider'))
	    ),
	    array(
	      "type" => "textfield",
	      "heading" => esc_html__("Number of items on phones", 'woopress-core'),
	      "param_name" => "phones",
	      "dependency" => Array('element' => "type", 'value' => array('slider'))
	    ),
	    array(
	      "type" => "dropdown",
	      "heading" => esc_html__("Products type", 'woopress-core'),
	      "param_name" => "products",
	      "value" => array( esc_html__("All", 'woopress-core') => '', esc_html__("Featured", 'woopress-core') => 'featured', esc_html__("New", 'woopress-core') => 'new', esc_html__("Sale", 'woopress-core') => 'sale', esc_html__("Recently viewed", 'woopress-core') => 'recently_viewed', esc_html__("Bestsellings", 'woopress-core') => 'bestsellings')
	    ),
	    array(
	      "type" => "dropdown",
	      "heading" => esc_html__("Hide out of stock products", 'woopress-core'),
	      "param_name" => "outofstock",
	      "value" => array(
	      	'No' => false,
	      	'Yes' => true
	       )
	    ),
	    array(
	      "type" => "textfield",
	      "heading" => esc_html__("Limit", 'woopress-core'),
	      "param_name" => "limit"
	    ),
	    array(
	      "type" => "textfield",
	      "heading" => esc_html__("Categories or Tags IDs", 'woopress-core'),
	      "param_name" => "categories"
	    )
	  )

	);

	vc_map($fpost_params);

}