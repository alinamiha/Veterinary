<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

function etheme_quick_view_shortcodes($atts, $content=null){
    extract(shortcode_atts(array(
        'id' => '',
        'class' => ''
    ), $atts));


    return '<div class="show-quickly-btn '.$class.'" data-prodid="'.$id.'">'. do_shortcode($content) .'</div>';

}