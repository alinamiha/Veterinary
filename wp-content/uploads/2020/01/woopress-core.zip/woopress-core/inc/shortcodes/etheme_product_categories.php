<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');


/**
 * List all (or limited) product categories
 *
 * @access public
 * @param array $atts
 * @return string
 */
if(!function_exists('etheme_product_categories')) {


	if( class_exists('Vc_Vendor_Woocommerce') ) {
      	$Vc_Vendor_Woocommerce = new Vc_Vendor_Woocommerce();
	  	add_filter( 'vc_autocomplete_etheme_product_categories_cat_ids_callback', array($Vc_Vendor_Woocommerce, 'productCategoryCategoryAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_etheme_product_categories_cat_ids_render', array($Vc_Vendor_Woocommerce, 'productCategoryCategoryRenderByIdExact',), 10, 1 );
		add_filter( 'vc_autocomplete_etheme_product_categories_parent_callback', array($Vc_Vendor_Woocommerce, 'productCategoryCategoryAutocompleteSuggester', ), 10, 1 );
		add_filter( 'vc_autocomplete_etheme_product_categories_parent_render', array($Vc_Vendor_Woocommerce, 'productCategoryCategoryRenderByIdExact',), 10, 1 );
    }

    function etheme_product_categories( $atts ) {
        global $woocommerce_loop;

        if ( !class_exists('Woocommerce') ) return false;

        extract( shortcode_atts( array(
            'number'     => null,
            'title'      => '',
            'orderby'    => 'name',
            'order'      => 'ASC',
            'hide_empty' => 1,
            'parent'     => '',
            'top_level'	 => '',
            'cat_ids'    => '',
            'display_type'=> 'grid',
            'class'      => ''
        ), $atts ) );

        if ( $top_level ) $parent = 0;

        if ( count (explode(",", $parent)) > 1 ) {
            $ids = explode( ',', $parent );
            $ids = array_map( 'trim', $ids );
        } else {
            $ids = array();
        }

        

        $title_output = '';

        if($title != '') {
            $title_output = '<h3 class="title"><span>' . $title . '</span></h3>';
        }

        $hide_empty = ( $hide_empty == true || $hide_empty == 1 ) ? 1 : 0;

        // get terms and workaround WP bug with parents/pad counts
        if ( $ids ) {

            $args = $result = $product_categories = array ();

            $i = 0;

            foreach ($ids as $key => $value ) {

                $args[$i] = array(
                	// 'menu_order' => true,
                    'orderby'    => $orderby,
                    'order'      => $order,
                    'hide_empty' => $hide_empty,
                    'pad_counts' => true,
                    'child_of'   => $value
                );

                $product_categories[$i] = get_terms( 'product_cat', $args[$i] );

                if ( $parent !== "" ) {
                    $product_categories[$i] = wp_list_filter( $product_categories[$i], array( 'parent' => $value ) );
                }

                if ( $hide_empty ) {
                    foreach ( $product_categories[$i] as $key => $category ) {
                        if ( $category->count == 0 ) {
                            unset( $product_categories[$i][ $key ] );
                        }
                    }
                }

                $result[] = $product_categories[$i];

            $i++;
            }
            if ( $number ) {
                $product_categories = array_slice( $result, 0, $number );
            }
        }
        else {
        	$cat_ids = array_filter( array_map( 'trim', explode( ',', $cat_ids ) ) );

            if ($cat_ids) {
            	array_push($cat_ids, $parent);
            	$args = array(
            		'orderby'    => $orderby,
	                'order'      => $order,
	                'hide_empty' => $hide_empty,
	                'include'    => $cat_ids,
	                'pad_counts' => true
	            );
            }
            else {
            	 $args = array(
	                'orderby'    => $orderby,
	                'order'      => $order,
	                'hide_empty' => $hide_empty,
	                'include'    => $ids,
	                'pad_counts' => true,
	                'child_of'   => $parent
	            );
            }

            $product_categories = get_terms( 'product_cat', $args );

            if ( $parent !== "" && ! ($cat_ids )) {
                $product_categories = wp_list_filter( $product_categories, array( 'parent' => $parent ) );
            }

            if ( $hide_empty ) {
                foreach ( $product_categories as $key => $category ) {
                    if ( $category->count == 0 ) {
                        unset( $product_categories[ $key ] );
                    }
                }
            }
            if ( $number ) {
                $product_categories = array_slice( $product_categories, 0, $number );
            }
        }


        //$woocommerce_loop['columns'] = $columns;

        if($display_type == 'slider') {
            $class .= ' owl-carousel carousel-area';
         } elseif(  $display_type == 'grid' ) {
            $class .= 'row';
        }

        $box_id = rand(1000,10000);

        ob_start();

        // Reset loop/columns globals when starting a new loop
        $woocommerce_loop['loop'] = $woocommerce_loop['column'] = '';

        $woocommerce_loop['display_type'] = $display_type;

        if ( $product_categories ) {
            if($display_type == 'menu') {

				if ( count( explode( ',',$parent ) ) === 1 && ! empty($parent) ) {

					$instance = array (
						'style'              => 'list',
						'child_of'           => $parent,
						'hierarchical' 		 => true,
						'title_li'           => ( '' ),
						'hide_empty' 		 => $hide_empty,
						'pad_counts' 		 => true,
						'orderby'    		=> $orderby,
						'order'      		=> $order,
						'number'             => null,
						'echo'               => 1,
						'taxonomy'           => 'product_cat',
					);
				}
				else {

					$instance = array (
						'style'              => 'list',
						'hierarchical' 		 => true,
						'title_li'           => ( '' ),
						'include'            => $cat_ids,
						'hide_empty' 		 => $hide_empty,
						'pad_counts' 		 => true,
						'orderby'    		 => $orderby,
						'order'      		 => $order,
						'number'             => null,
						'echo'               => 1,
						'taxonomy'           => 'product_cat',
					);
				}

				echo '<div class="categories-menu-element '.$class.' product-categories">';
					echo '<h2>'.$title.'</h2>';
					wp_list_categories($instance);
				echo '</div>';
            } else {

            	echo $title_output;

	            echo '<div class="categoriesCarousel '.$class.' slider-'.$box_id.'">';

	            foreach ( $product_categories as $category ) {

                    if ( count (explode(",", $parent)) > 1 ) {
                        foreach ($category as $key ) {
                            wc_get_template( 'content-product_cat.php', array(
                            'category' => $key
                            ) );
                        }
                    }
                    else {

    	                wc_get_template( 'content-product_cat.php', array(
    	                    'category' => $category
    	                ) );
                    }

	            }

	            echo '</div>';

            }


            if($display_type == 'slider') {
                echo '
					<script type="text/javascript">
						jQuery(".slider-'.$box_id.'").owlCarousel({
								items:4,
								nav: true,
								navText:["",""],
								lazyLoad: true,
								rewind:false,
								responsive: {
									0: {
										items: 1
									},
									479: {
										items: 2
									},
									619: {
										items: 3
									},
									768: {
										items: 3
									},
									1200: {
										items: 4
									},
									1600 : {
										items: 4
									}
								}
							});
					</script>
                ';
            }

        }

        woocommerce_reset_loop();

        return ob_get_clean();
    }
}


// **********************************************************************//
	    // ! Register New Element: Product categories
	    // **********************************************************************//

	    $brands_params = array(
	      'name' => 'Product categories',
	      'base' => 'etheme_product_categories',
	      'icon' => 'icon-wpb-etheme',
	      'category' => 'Eight Theme',
	      'params' => array(
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Title", 'woopress-core'),
	          "param_name" => "title"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Number of categories", 'woopress-core'),
	          "param_name" => "number"
	        ),
	        array(
	          'type' => 'autocomplete',
	          "heading" => esc_html__("Parent ID", 'woopress-core'),
	          "param_name" => "parent",
			  'settings' => array(
				'multiple' => false,
				'sortable' => false,
			  ),
			  'save_always' => true,
              "description" => esc_html__('Get direct children of this term (only terms whose explicit parent is this value). Default is an empty string.', 'woopress-core')
		    ),
		    array(
              "type" => "checkbox",
              "heading" => esc_html__("Only top-level categories", 'woopress-core'),
              "param_name" => "top_level",
            ),
		    array(
	          'type' => 'autocomplete',
	          "heading" => esc_html__("Categories IDs", 'woopress-core'),
	          "param_name" => "cat_ids",
			  'settings' => array(
				'multiple' => true,
				'sortable' => true,
			  ),
			  'save_always' => true,
              "description" => esc_html__('Write down ids of categories you want to show. ( It will work only if Parent ID area is empty. )', 'woopress-core')
		    ),

		    array(
              "type" => "dropdown",
              "heading" => esc_html__("Order by", 'woopress-core'),
              "param_name" => "orderby",
              "value" => array(
                  esc_html__( 'Date' )             => 'date',
                  esc_html__( 'ID' )               => 'ID',
                  esc_html__( 'Author' )           => 'author',
                  esc_html__( 'Title' )            => 'title',
                  esc_html__( 'Modified' )         => 'modified',
                  esc_html__( 'Rand' )             => 'rand',
                  esc_html__( 'Comment count' )    => 'comment_count',
                  esc_html__( 'Menu order' )       => 'menu_order',
                  esc_html__( 'Menu order title' ) => 'menu_order_title',
                  esc_html__( 'Include' )          => 'include'
                )
            ),

            array(
              "type" => "dropdown",
              "heading" => esc_html__("Sort order", 'woopress-core'),
              "param_name" => "order",
              "value" => array(
                  esc_html__("Ascending", 'woopress-core') => 'ASC',
                  esc_html__("Descending", 'woopress-core') => 'DESC',
                )
            ),

	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Display type", 'woopress-core'),
	          "param_name" => "display_type",
	          "value" => array(
	              esc_html__("Grid", 'woopress-core') => 'grid',
	              esc_html__("Slider", 'woopress-core') => 'slider',
	              esc_html__("Menu", 'woopress-core') => 'menu'
	            )
	        ),
	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Show empty categories", 'woopress-core'),
	          "param_name" => "hide_empty",
	          "value" => array(
	          	esc_html__("Hide", 'woopress-core') => 1,
	              esc_html__("Show", 'woopress-core') => 0
	            )
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Extra Class", 'woopress-core'),
	          "param_name" => "class"
	        )
	      )

	    );

	    vc_map($brands_params);