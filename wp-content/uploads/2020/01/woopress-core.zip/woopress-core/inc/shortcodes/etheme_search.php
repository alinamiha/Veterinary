<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

/***************************************************************/
/* Etheme Global Search */
/***************************************************************/
if(!function_exists('etheme_search')) {
	function etheme_search($atts) {
		extract( shortcode_atts( array(
			'products' => 0,
			'posts' => 0,
			'portfolio' => 0,
			'pages' => 0,
			'testimonial' => 0,
			'images' => 1,
			'count' => 3,
			'class' => '',
			'text' => 'Go',
			'post_type' => 'product',
			'widget' => 0
		), $atts ) );

		$search_input = $output = '';

		switch ($post_type) {
			case 'product':
				$products = 1;
			break;

			case 'etheme_portfolio':
				$portfolio = 1;
			break;

			case 'post':
				$posts = 1;
			break;

			case 'page':
				$pages = 1;
			break;

			case 'testimonial':
				$testimonial =1;
			break;

			case 'any':
				$posts = 1;
				$products = 1;
				$pages = 1;
				$portfolio = 1;
				$testimonial =1;
			break;

			default:
				$products = 1;
			break;
		}

		if(get_search_query() != '') {
			$search_input = get_search_query();
		}

		$output .= '<div class="et-mega-search '.$class.'" data-products="'.$products.'" data-count="'.$count.'" data-posts="'.$posts.'" data-portfolio="'.$portfolio.'" data-pages="'.$pages.'" data-testimonial="'.$testimonial.'" data-images="'.$images.'">';

			$output .= '<form method="get" action="'.home_url( '/' ).'">';
				$output .= '<input type="text" value="'.$search_input.'" name="s" autocomplete="off" placeholder="'.esc_html__('Search', 'woopress-core').'"/>';

				$output .= '<input type="hidden" name="post_type" value="'.$post_type.'"/>';

				$output .= '<input type="submit" value="'. $text .'" class="button active filled"  /> ';
			$output .= '</form>';
			$output .= '<span class="et-close-results"></span>';
			$output .= '<div class="et-search-result">';
			$output .= '</div>';
		$output .= '</div>';

		return $output;

	}
}



// **********************************************************************//
	    // ! Register New Element: Search Form
	    // **********************************************************************//

	    $search_params = array(
	      'name' => 'Mega Search Form',
	      'base' => 'etheme_search',
	      'icon' => 'icon-wpb-etheme',
	      'category' => 'Eight Theme',
	      'params' => array(

	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Search type", 'woopress-core'),
	          "param_name" => "post_type",
	          "value" => array(
	          	esc_html__("Products", 'woopress-core') => 'product',
	          	esc_html__("Posts", 'woopress-core') => 'post',
	          	esc_html__("Portfolio", 'woopress-core') => 'etheme_portfolio',
	          	esc_html__("Pages", 'woopress-core') => 'page',
	          	esc_html__("Testimonial", 'woopress-core') => 'testimonial',
	          	esc_html__("All", 'woopress-core') => 'any',

	          )
	        ),
	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Display images", 'woopress-core'),
	          "param_name" => "images",
	          "value" => array(
	              "",
	              esc_html__("Yes", 'woopress-core') => 1,
	              esc_html__("No", 'woopress-core') => 0
	            )
	        ),
	        // array(
	        //   "type" => "dropdown",
	        //   "heading" => esc_html__("Search for products", 'woopress-core'),
	        //   "param_name" => "products",
	        //   "value" => array(
	        //       "",
	        //       __("Yes", ETHEME_DOMAIN) => 1,
	        //       __("No", ETHEME_DOMAIN) => 0
	        //     )
	        // ),
	        // array(
	        //   "type" => "dropdown",
	        //   "heading" => __("Search for posts", 'woopress-core'),
	        //   "param_name" => "posts",
	        //   "value" => array(
	        //       "",
	        //       __("Yes", ETHEME_DOMAIN) => 1,
	        //       __("No", ETHEME_DOMAIN) => 0
	        //     )
	        // ),
	        // array(
	        //   "type" => "dropdown",
	        //   "heading" => __("Search in portfolio", 'woopress-core'),
	        //   "param_name" => "portfolio",
	        //   "value" => array(
	        //       "",
	        //       __("Yes", ETHEME_DOMAIN) => 1,
	        //       __("No", ETHEME_DOMAIN) => 0
	        //     )
	        // ),
	        // array(
	        //   "type" => "dropdown",
	        //   "heading" => __("Search for pages", 'woopress-core'),
	        //   "param_name" => "pages",
	        //   "value" => array(
	        //       "",
	        //       __("Yes", ETHEME_DOMAIN) => 1,
	        //       __("No", ETHEME_DOMAIN) => 0
	        //     )
	        // ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Number of items", 'woopress-core'),
	          "param_name" => "count"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Extra Class", 'woopress-core'),
	          "param_name" => "class"
	        )
	      )

	    );

	    vc_map($search_params);