<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

function etheme_row_shortcode($atts, $content = null) {
    $a = shortcode_atts( array(
        'class' => ''
    ), $atts);

    $class = '';

    return '<div class="row'.$class . ' ' . $a['class'] . '">' . do_shortcode($content) . '</div>';
}