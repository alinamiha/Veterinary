<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

/***************************************************************/
/* TWITTER SLIDER */
/***************************************************************/

if(!function_exists('et_twitter_slider')) {
	function et_twitter_slider($atts) {
		extract( shortcode_atts( array(
			'title' => '',
			'user' => '',
			'consumer_key' => '',
			'consumer_secret' => '',
			'user_token' => '',
			'user_secret' => '',
			'limit' => 10,
			'class' => 10
		), $atts ) );

		if(empty($consumer_key) || empty($consumer_secret) || empty($user_token) || empty($user_secret) || empty($user)) {
			return esc_html__('Not enough information', 'woopress-core');
		}

		$tweets_array = et_get_tweets($consumer_key, $consumer_secret, $user_token, $user_secret, $user, $limit);
		$output = '';

		$output .= '<div class="et-twitter-slider '.$class.'">';
		if($title != '') {
			$output .= '<h2 class="twitter-slider-title"><span>'.$title.'</span></h2>';
		}


		$output .= '<ul class="owl-carousel et-tweets">';


		foreach($tweets_array as $tweet) {
			$output .= '<li class="et-tweet">';
			$output .= etheme_tweet_linkify($tweet['text']);
			$output .= '<div class="twitter-info">';
                            $output .= '<a href="'.$tweet['user']['url'].'" class="active" target="_blank">@'.$tweet['user']['screen_name'].'</a> '.date("l M j \- g:ia",strtotime($tweet['created_at']));
			$output .= '</div>';
			$output .= '</li>';
		}

		$output .= '</ul>';

		$output .= '</div>';

		$items   = '{0:{items:1}, 479:{items:1}, 619:{items:1}, 768:{items:1},  1200:{items:1}, 1600:{items:1}}';
		$output .=  '<script type="text/javascript">';
		$output .=  '     jQuery(".et-tweets").owlCarousel({';
		$output .=  '         items:1, ';
		$output .=  '         nav: true,';
		$output .=  '         navText:["",""],';
		$output .=  '         rewind: false,';
		$output .=  '         responsive: '.$items.'';
		$output .=  '    });';

		$output .=  ' </script>';

		return $output;

	}
}


if(!function_exists('et_get_tweets')) {
	function et_get_tweets($consumer_key = 'Ev0u7mXhBvvVaLOfPg2Fg', $consumer_secret = 'SPdZaKNIeBlUo99SMAINojSJRHr4EQXPSkR0Dw97o', $user_token = '435115014-LVrLsvzVAmQWjLw1r8KjNy93QiXHWKH09kcIQCKh', $user_secret = 'eTxZP8jQfB7DjKAAoJx1AFsTd3wPfImNaqau6HIVw', $user = '8theme', $count = 10) {
	    if(etheme_twitter_cache_enabled()){
	        //setting the location to cache file
	        $cachefile = ETHEME_CODE_DIR . '/cache/twitterSliderCache.json';
	        $cachetime = 50;

	        // the file exitsts but is outdated, update the cache file
	        if (file_exists($cachefile) && ( time() - $cachetime > filemtime($cachefile)) && filesize($cachefile) > 0) {
	            //capturing fresh tweets
	            $tweets = etheme_capture_tweets($consumer_key,$consumer_secret,$user_token,$user_secret,$user, $count);
	            $tweets_decoded = json_decode($tweets, true);
	            //if get error while loading fresh tweets - load outdated file
	            if(isset($tweets_decoded['error'])) {
	                $tweets = etheme_pick_tweets($cachefile);
	            }
	            //else store fresh tweets to cache
	            else
	                etheme_store_tweets($cachefile, $tweets);
	        }
	        //file doesn't exist or is empty, create new cache file
	        elseif (!file_exists($cachefile) || filesize($cachefile) == 0) {
	            $tweets = etheme_capture_tweets($consumer_key,$consumer_secret,$user_token,$user_secret,$user, $count);
	            $tweets_decoded = json_decode($tweets, true);
	            //if request fails, and there is no old cache file - print error
	            if(isset($tweets_decoded['error']))
	                return 'Error: ' . $tweets_decoded['error'];
	            //make new cache file with request results
	            else
	                etheme_store_tweets($cachefile, $tweets);
	        }
	        //file exists and is fresh
	        //load the cache file
	        else {
	           $tweets = etheme_pick_tweets($cachefile);
	        }
	    } else{
	       $tweets = etheme_capture_tweets($consumer_key,$consumer_secret,$user_token,$user_secret,$user, $count);
	    }

	    $tweets = json_decode($tweets, true);
	    return $tweets;
	}
}



// **********************************************************************//
	    // ! Register New Element: Twitter Slider
	    // **********************************************************************//

	    $twitter_params = array(
	      'name' => 'Twitter Slider',
	      'base' => 'twitter_slider',
	      'icon' => 'icon-wpb-etheme',
	      'category' => 'Eight Theme',
	      'params' => array(
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Title", 'woopress-core'),
	          "param_name" => "title"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("User account name", 'woopress-core'),
	          "param_name" => "user"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Consumer Key", 'woopress-core'),
	          "param_name" => "consumer_key"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Consumer Secret", 'woopress-core'),
	          "param_name" => "consumer_secret"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("User Token", 'woopress-core'),
	          "param_name" => "user_token"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("User Secret", 'woopress-core'),
	          "param_name" => "user_secret"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Limit", 'woopress-core'),
	          "param_name" => "limit"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Extra Class", 'woopress-core'),
	          "param_name" => "class"
	        )
	      )

	    );

	    vc_map($twitter_params);