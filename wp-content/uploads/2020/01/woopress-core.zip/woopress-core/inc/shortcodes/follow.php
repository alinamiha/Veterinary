<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

// **********************************************************************//
// ! Follow
// **********************************************************************//

function et_follow_shortcode($atts) {
    extract(shortcode_atts(array(
        'title'  => '',
        'size' => 'normal',
        'target' => '_blank',
        'facebook' => '',
        'twitter' => '',
        'instagram' => '',
        'google' => '',
        'pinterest' => '',
        'linkedin' => '',
        'tumblr' => '',
        'youtube' => '',
        'vimeo' => '',
        'rss' => '',
        'colorfull' => '',
        'class' => '',
    ), $atts));

    $class .= ' buttons-size-'.$size;

    if( $colorfull ) {
        $class .= ' icons-colorfull';
    }

    $target = 'target="' . $target . '"';

    $output = '<div class="et-follow-buttons '.$class.'">';

    if( $facebook ) {
        $output .= '<a href="'. esc_url( $facebook ) .'" class="follow-facebook" '.$target.'><i class="fa fa-facebook"></i></a>';
    }

    if( $twitter ) {
        $output .= '<a href="'. esc_url( $twitter ) .'" class="follow-twitter" '.$target.'><i class="fa fa-twitter"></i></a>';
    }

    if( $instagram ) {
        $output .= '<a href="'. esc_url( $instagram ) .'" class="follow-instagram" '.$target.'><i class="fa fa-instagram"></i></a>';
    }

    if( $google ) {
        $output .= '<a href="'. esc_url( $google ) .'" class="follow-google" '.$target.'><i class="fa fa-google"></i></a>';
    }

    if( $pinterest ) {
        $output .= '<a href="'. esc_url( $pinterest ) .'" class="follow-pinterest" '.$target.'><i class="fa fa-pinterest"></i></a>';
    }

    if( $linkedin ) {
        $output .= '<a href="'. esc_url( $linkedin ) .'" class="follow-linkedin" '.$target.'><i class="fa fa-linkedin"></i></a>';
    }

    if( $tumblr ) {
        $output .= '<a href="'. esc_url( $tumblr ) .'" class="follow-tumblr" '.$target.'><i class="fa fa-tumblr"></i></a>';
    }

    if( $youtube ) {
        $output .= '<a href="'. esc_url( $youtube ) .'" class="follow-youtube" '.$target.'><i class="fa fa-youtube"></i></a>';
    }

    if( $vimeo ) {
        $output .= '<a href="'. esc_url( $vimeo ) .'" class="follow-vimeo" '.$target.'><i class="fa fa-vimeo"></i></a>';
    }

    if( $rss ) {
        $output .= '<a href="'. esc_url( $rss ) .'" class="follow-rss" '.$target.'><i class="fa fa-rss"></i></a>';
    }

    $output .= '</div>';

    return $output;

}




// **********************************************************************//
// ! Register New Element: Follow
// **********************************************************************//

$follow_params = array(
  'name' => 'Social links',
  'base' => 'follow',
  'icon' => 'icon-wpb-etheme',
  'category' => 'Eight Theme',
  'params' => array(
    array(
      "type" => "textfield",
      "heading" => "Title",
      "param_name" => "title"
    ),
    array(
      "type" => "textfield",
      "heading" => "Facebook",
      "param_name" => "facebook"
    ),
    array(
      "type" => "textfield",
      "heading" => "Twitter",
      "param_name" => "twitter"
    ),
    array(
      "type" => "textfield",
      "heading" => "Instagram",
      "param_name" => "instagram"
    ),
    array(
      "type" => "textfield",
      "heading" => "Google",
      "param_name" => "google"
    ),
    array(
      "type" => "textfield",
      "heading" => "Pinterest",
      "param_name" => "pinterest"
    ),
    array(
      "type" => "textfield",
      "heading" => "Linkedin",
      "param_name" => "linkedin"
    ),
    array(
      "type" => "textfield",
      "heading" => "Tumblr",
      "param_name" => "tumblr"
    ),
    array(
      "type" => "textfield",
      "heading" => "Youtube",
      "param_name" => "youtube"
    ),
     array(
      "type" => "textfield",
      "heading" => "Vimeo",
      "param_name" => "vimeo"
    ),
      array(
      "type" => "textfield",
      "heading" => "RSS",
      "param_name" => "rss"
    ),
    array(
      "type" => "checkbox",
      "heading" => esc_html__("Colorfull icons", 'woopress-core'),
      "param_name" => "colorfull",
    ),
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Link Target", 'woopress-core'),
      "param_name" => "target",
      "value" => array( esc_html__("Blank", 'woopress-core') => "_blank", esc_html__("Current window", 'woopress-core') => "_self")
    ),
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Size", 'woopress-core'),
      "param_name" => "size",
      "value" => array( esc_html__("Normal", 'woopress-core') => "normal", esc_html__("Large", 'woopress-core') => "large", esc_html__("Small", 'woopress-core') => "small"),
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Extra class name", 'woopress-core'),
      "param_name" => "class"
    ),

  )

);

vc_map($follow_params);