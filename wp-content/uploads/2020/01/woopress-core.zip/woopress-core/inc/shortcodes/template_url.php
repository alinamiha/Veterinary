<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

function etheme_template_url_shortcode(){
    return get_template_directory_uri();
}