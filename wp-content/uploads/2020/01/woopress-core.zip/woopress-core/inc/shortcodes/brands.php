<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');


if(!function_exists('et_brands')) {
	function et_brands($atts) {
		if ( ! function_exists( 'woopress_core_load_textdomain' ) ) {
			return;
		}
        extract( shortcode_atts( array(
            'number'     => null,
            'title'      => '',
            'orderby'    => 'name',
            'order'      => 'ASC',
            'columns'    => 3,
            'parent'     => '',
            'display_type'=> 'slider',
            'class'      => ''
        ), $atts ) );

        if ( isset( $atts[ 'ids' ] ) ) {
            $ids = explode( ',', $atts[ 'ids' ] );
            $ids = array_map( 'trim', $ids );
        } else {
            $ids = array();
        }


        // get terms and workaround WP bug with parents/pad counts
        $args = array(
            'orderby'    => $orderby,
            'order'      => $order,
            'hide_empty' => 1,
            'include'    => $ids,
            'pad_counts' => true,
            'child_of'   => $parent
        );

        $terms = get_terms( 'brand', $args );

        if ( $parent !== "" ) {
            $terms = wp_list_filter( $terms, array( 'parent' => $parent ) );
        }

        if ( $number ) {
            $terms = array_slice( $terms, 0, $number );
        }


		$output = '';
		$rand = rand(1000,9999);

		$count = count($terms); $i=0;
		if ($count > 0) {
			$output .= '<div class="carousel-area et-brands-'.$display_type.' '.$class.' columns-number-'.$columns.'">';
			if($title != '') {
				$output .= '<h2 class="brands-title title"><span>'.$title.'</span></h2>';
			}
			if ($display_type == 'slider') {
				$output .= '<div class="owl-carousel brandCarousel'.$rand.'">';
			}else{
				$output .= '<div class="brandCarousel'.$rand.'">';
			}

		    foreach ($terms as $term) {
		        $i++;
		        $thumbnail_id 	= absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) );
				$output .= '<div class="et-brand">';
				if($thumbnail_id) {
					$output .= '<a href="' . get_term_link( $term ) . '" title="' . esc_html__('View all products from ', 'woopress-core') . $term->name . '"><img src="' . etheme_get_image($thumbnail_id) . '" title="' . $term->name . '"/></a>';
				} else {
					$output .= '<h3><a href="' . get_term_link( $term ) . '" title="' . esc_html__('View all products from ', 'woopress-core') . $term->name . '">' . $term->name . '</a></h3>';
				}
				$output .= '</div>';
		    }

		    $output .= '</div>';
			$output .= '</div>';

			if($display_type == 'slider') {
				$items = '{0:{items:1}, 479:{items:1}, 619:{items:2}, 768:{items:3},  1200:{items:4}, 1600:{items:4}}';
				$output .=  '<script type="text/javascript">';
				$output .=  '     jQuery(".brandCarousel'.$rand.'").owlCarousel({';
				$output .=  '         items:4, ';
				$output .=  '         nav: true,';
				$output .=  '         navText:["",""],';
				$output .=  '         rewind: false,';
				$output .=  '         responsive: '.$items.'';
				$output .=  '    });';

				$output .=  ' </script>';
			}

		}



		return $output;
	}
}




// **********************************************************************//
	    // ! Register New Element: Brands
	    // **********************************************************************//

	    $brands_params = array(
	      'name' => 'Brands',
	      'base' => 'brands',
	      'icon' => 'icon-wpb-etheme',
	      'category' => 'Eight Theme',
	      'params' => array(
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Title", 'woopress-core'),
	          "param_name" => "title"
	        ),
	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Display type", 'woopress-core'),
	          "param_name" => "display_type",
	          "value" => array(
	              esc_html__("Slider", 'woopress-core') => 'slider',
	              esc_html__("Grid", 'woopress-core') => 'grid'
	            )
	        ),
	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Number of columns", 'woopress-core'),
	          "param_name" => "columns",
	          "dependency" => Array('element' => "display_type", 'value' => array('grid')),
	          "value" => array(
	              '2' => 2,
	              '3' => 3,
	              '4' => 4,
	              '5' => 5,
	              '6' => 6,
	            )
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Number of brands", 'woopress-core'),
	          "param_name" => "number"
	        ),
		    array(
		      "type" => "dropdown",
		      "heading" => esc_html__("Order by", 'woopress-core'),
		      "param_name" => "orderby",
		      "value" => array( "", esc_html__("ID", 'woopress-core') => "id", esc_html__("Count", 'woopress-core') => "count", esc_html__("Name", 'woopress-core') => "name",  esc_html__("Slug", 'woopress-core') => "slug"),

		    ),
		    array(
		      "type" => "dropdown",
		      "heading" => esc_html__("Order way", 'woopress-core'),
		      "param_name" => "order",
		      "value" => array( esc_html__("Descending", 'woopress-core') => "DESC", esc_html__("Ascending", 'woopress-core') => "ASC" ),
		      "description" => sprintf(esc_html__('Designates the ascending or descending order. More at %s.', 'js_composer'), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>')
		    ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Parent ID", 'woopress-core'),
	          "param_name" => "parent",
              "description" => esc_html__('Get direct children of this term (only terms whose explicit parent is this value). If 0 is passed, only top-level terms are returned. Default is an empty string.', 'woopress-core')
		    ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Extra Class", 'woopress-core'),
	          "param_name" => "class"
	        )
	      )

	    );

	    vc_map($brands_params);