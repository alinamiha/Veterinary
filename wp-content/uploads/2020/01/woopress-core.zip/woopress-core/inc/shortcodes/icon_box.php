<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');


// **********************************************************************//
// ! Icon Box
// **********************************************************************//

function etheme_icon_box_shortcode($atts, $content = null) {
    $a = shortcode_atts(array(
        'title' => '',
        'icon' => 'bolt',
        'icon_position' => 'left',
        'icon_style' => '',
        'color' => '',
        'bg_color' => '',
        'color_hover' => '',
        'bg_color_hover' => '',
        'text' => ''
    ),$atts);

    $box_id = rand(1000,10000);


    $output = '';
    $output .= '<div class="block-with-ico ico-box-'.$box_id.' ico-position-'.$a['icon_position'].' ico-style-'.$a['icon_style'].'">';
        $output .= '<i class="fa fa-'.$a['icon'].'" ></i>';
        $output .= '<div class="ico-box-content">';
        $output .= '<h5>'.$a['title'].'</h5>';
        $output .= do_shortcode($content).do_shortcode($a['text']);
        $output .= '</div>';
    $output .= '</div>';
    $output .= '<style>';
    $output .= '.ico-box-'.$box_id.' i {';
    if($a['color'] != '') {
	    $output .= 'color:'.$a['color'].'!important;';
    }
    if($a['bg_color'] != '') {
	    $output .= 'background:'.$a['bg_color'].'!important;';
    }
    $output .= '}';
    $output .= '.ico-box-'.$box_id.':hover i {';
    if($a['color_hover'] != '') {
    	$output .= 'color:'.$a['color_hover'].'!important;';
    }
    if($a['bg_color_hover'] != '') {
    	$output .= 'background:'.$a['bg_color_hover'].'!important;';
    }
    $output .= '}';
    $output .= '</style>';


    return $output;
}



// **********************************************************************//
	    // ! Register New Element: Icon Box
	    // **********************************************************************//

	    $icon_box_params = array(
	      'name' => 'Icon Box',
	      'base' => 'icon_box',
	      'icon' => 'icon-wpb-etheme',
	      'category' => 'Eight Theme',
	      'params' => array(
	        array(
	          'type' => 'textfield',
	          "heading" => esc_html__("Box title", 'woopress-core'),
	          "param_name" => "title"
	        ),
	        array(
	          'type' => 'icon',
	          "heading" => esc_html__("Icon", 'woopress-core'),
	          "param_name" => "icon"
	        ),
	        array(
	          'type' => 'colorpicker',
	          "heading" => esc_html__("Icon Color", 'woopress-core'),
	          "param_name" => "color"
	        ),
	        array(
	          'type' => 'colorpicker',
	          "heading" => esc_html__("Background Color", 'woopress-core'),
	          "param_name" => "bg_color"
	        ),
	        array(
	          'type' => 'colorpicker',
	          "heading" => esc_html__("Icon Color [HOVER]", 'woopress-core'),
	          "param_name" => "color_hover"
	        ),
	        array(
	          'type' => 'colorpicker',
	          "heading" => esc_html__("Background Color [HOVER]", 'woopress-core'),
	          "param_name" => "bg_color_hover"
	        ),
	        array(
	          "type" => "textarea_html",
	          'admin_label' => true,
	          "heading" => esc_html__("Text", 'woopress-core'),
	          "param_name" => "content",
	          "value" => esc_html__("Click edit button to change this text.", 'woopress-core'),
	          "description" => esc_html__("Enter your content.", 'woopress-core')
	        ),
	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Icon Position", 'woopress-core'),
	          "param_name" => "icon_position",
	          "value" => array(
	              "",
	              esc_html__("Top", 'woopress-core') => 'top',
	              esc_html__("Left", 'woopress-core') => 'left'
	            )
	        ),
	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Icon Style", 'woopress-core'),
	          "param_name" => "icon_style",
	          "value" => array(
	              esc_html__("Encircled", 'woopress-core') => 'encircled',
	              esc_html__("Small", 'woopress-core') => 'small',
	              esc_html__("Large", 'woopress-core') => 'large'
	            )
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Extra Class", 'woopress-core'),
	          "param_name" => "class",
	          "description" => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'woopress-core')
	        )
	      )

	    );

	    //vc_map($icon_box_params);