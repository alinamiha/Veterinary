<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');



// **********************************************************************//
// ! Progress Bar
// **********************************************************************//

function etheme_progress_shortcode($atts) {
    $a = shortcode_atts(array(
        'complete' => '',
        'color' => '',
        'title'    => ''
    ),$atts);

    $style = '';

    if($a['complete'] > 100) {
        $a['complete'] = 100;
    }elseif($a['complete'] < 0) {
        $a['complete'] = 0;
    }

    if ($a['color'] != '') {
        $style = 'background-color:'.$a['color'];
    }

    return '<div class="progress-bars"><div class="progress-bar" data-width="'.$a['complete'].'" style="'.$style.'"><span>'.$a['title'].'</span><div></div></div></div>';
}