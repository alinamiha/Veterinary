<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');


function etheme_column_shortcode($atts, $content = null) {
    $a = shortcode_atts( array(
        'size' => 'one_half',
        'class' => '',
    ), $atts);
    switch($a['size']) {
        case 'one-half':
            $class = 'col-md-6 ';
        break;
        case 'one-third':
            $class = 'col-md-4 ';
        break;
        case 'two-third':
            $class = 'col-md-8 ';
        break;
        case 'one-fourth':
            $class = 'col-md-3 ';
        break;
        case 'three-fourth':
            $class = 'col-md-9 ';
        break;
        default:
            $class = $a['size'];
        }

        $class .= ' '.$a['class'];

        return '<div class="' . $class . '">' . do_shortcode($content) . '</div>';
}