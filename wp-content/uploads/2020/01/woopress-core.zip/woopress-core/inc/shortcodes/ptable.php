<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

// **********************************************************************//
// ! Pricing Tables
// **********************************************************************//

function etheme_ptable_shortcode($atts, $content = null) {
    $a = shortcode_atts(array(
        'class' => '',
        'style' => 2,
        'columns' => 1,
        'content' => ''
    ),$atts);
    return '<div class="pricing-table columns'.$a['columns'].' '.$a['class'].' style'.$a['style'].'">'.do_shortcode($content.$a['content']).'</div>';
}



// **********************************************************************//
// ! Register New Element:Pricing Table
// **********************************************************************//
$demoTable = "\n\t".'<ul>';
$demoTable .= "\n\t\t".'<li class="row-title">Free</li>';
$demoTable .= "\n\t\t".'<li class="row-price"><sup class="currency">$</sup>19<sup>00</sup><sub>per month</sub></li>';
$demoTable .= "\n\t\t".'<li>512 mb</li>';
$demoTable .= "\n\t\t".'<li>0.6 GHz</li>';
$demoTable .= "\n\t\t".'<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>';
$demoTable .= "\n\t\t".'<li><a href="#" class="button">Add to Cart</a></li>';
$demoTable .= "\n\t".'</ul>';


$ptable_params = array(
  'name' => 'Pricing Table',
  'base' => 'ptable',
  'icon' => 'icon-wpb-etheme',
  'category' => 'Eight Theme',
  'params' => array(
    array(
      "type" => "textarea_html",
      "holder" => "div",
      "heading" => "Table",
      "param_name" => "content",
      "value" => $demoTable
    ),
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Style", 'woopress-core'),
      "param_name" => "style",
      "value" => array( "", esc_html__("default", 'woopress-core') => "default", esc_html__("Style 2", 'woopress-core') => "style2")
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Extra Class", 'woopress-core'),
      "param_name" => "class",
      "description" => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'woopress-core')
    )
  )

);

vc_map($ptable_params);