<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

// **********************************************************************//
// ! Recent posts shortcodes
// **********************************************************************//

function etheme_recent_posts_shortcode($atts){
    $a = shortcode_atts( array(
       'title' => 'Recent Posts',
       'limit' => 10,
       'cat' => '',
       'imgwidth' => 300,
       'imgheight' => 200,
       'imgcrop' => 1,
       'date' => 0,
       'excerpt' => 0,
       'more_link' => 1
   ), $atts );


    $args = array(
        'post_type'             => 'post',
        'ignore_sticky_posts'   => 1,
        'no_found_rows'         => 1,
        'posts_per_page'        => $a['limit'],
        'cat'                   => $a['cat']
    );

    $crop = ($a['imgcrop'] == 1);

    ob_start();
    etheme_create_posts_slider($args, $a['title'], $a['more_link'], $a['date'], $a['excerpt'], $a['imgwidth'], $a['imgheight'], $crop );
    $output = ob_get_contents();
    ob_end_clean();

    return $output;

}