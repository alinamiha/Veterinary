<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');



// **********************************************************************//
// ! Title with subtitle
// **********************************************************************//

function etheme_title_shortcode($atts, $content = null) {
    $a = shortcode_atts( array(
        'heading' => '2',
        'subtitle' => '',
        'align' => 'center',
        'subtitle' => '',
        'line' => 1
    ), $atts);
    $subtitle = '';
    $class = 'title';
    $class .= ' text-'.$a['align'];
    if(!$a['line']) {
        $class .= ' without-line';
    }
    if($a['subtitle'] != '') {
        $class .= ' with-subtitle';
        $subtitle = '<span class="subtitle text-'.$a['align'].'">'.$a['subtitle'].'</span>';
    }

    return '<h'.$a['heading'].' class="'.$class.'"><span>'.$content.'</span></h'.$a['heading'].'>'.$subtitle;
}
