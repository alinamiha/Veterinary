<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

// **********************************************************************//
// ! Recent comments widget shortcode
// **********************************************************************//

function etheme_recent_comments_shortcode($atts, $content = null) {
    $a = shortcode_atts(array(
        'title' => '',
        'number' => 5
    ),$atts);

    $widget = new Etheme_Recent_Comments_Widget();

    $args = array(
        'before_widget' => '<div class="sidebar-widget etheme_widget_recent_comments">',
        'after_widget' => '</div><!-- //sidebar-widget -->',
        'before_title' => '<h4 class="widget-title">',
        'after_title' => '</h4>',
        'widget_id' => 'etheme_widget_recent_comments',
    );
    $instance = array(
        'title' => $a['title'],
        'number' => $a['number']
    );

    ob_start();
    $widget->widget($args, $instance);
    $output = ob_get_contents();
    ob_end_clean();

    return $output;
}



        // **********************************************************************//
        // ! Register New Element: Recent Comments Widget
        // **********************************************************************//

        $recent_comments_params = array(
          'name' => 'Recent comments widget',
          'base' => 'et_recent_comments',
          'icon' => 'icon-wpb-etheme',
          'category' => 'Eight Theme',
          'params' => array(
            array(
              'type' => 'textfield',
              "heading" => esc_html__("Widget title", 'woopress-core'),
              "param_name" => "title",
              "description" => esc_html__("What text use as a widget title. Leave blank if no title is needed.", 'woopress-core')
            ),
            array(
              "type" => "textfield",
              "heading" => esc_html__("Limit", 'woopress-core'),
              "param_name" => "number",
              "description" => esc_html__('How many testimonials to show? Enter number.', 'woopress-core')
            )
          )

        );

        vc_map($recent_comments_params);