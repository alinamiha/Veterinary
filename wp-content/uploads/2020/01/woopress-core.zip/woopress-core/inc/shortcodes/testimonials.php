<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');


// **********************************************************************//
// ! Testimonials
// **********************************************************************//


// **********************************************************************//
// ! Register New Element: Testimonials Widget
// **********************************************************************//

$testimonials_params = array(
  'name' => 'Testimonials widget',
  'base' => 'testimonials',
  'icon' => 'icon-wpb-etheme',
  'category' => 'Eight Theme',
  'params' => array(
    array(
      "type" => "textfield",
      "heading" => esc_html__("Limit", 'woopress-core'),
      "param_name" => "limit",
      "description" => esc_html__('How many testimonials to show? Enter number.', 'woopress-core')
    ),
	array(
	   "type" => "dropdown",
	   "heading" => esc_html__("Order Direction", 'woopress-core'),
	   "param_name" => "orderby",
	   "value" => array(
		   "",
		   esc_html__("Ascending", 'woopress-core') => 'id',
		   esc_html__("Descending", 'woopress-core') => 'menu_order'
		 )
	 ),
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Display type", 'woopress-core'),
      "param_name" => "type",
      "value" => array(
          "",
          esc_html__("Slider", 'woopress-core') => 'slider',
          esc_html__("Grid", 'woopress-core') => 'grid'
        )
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Interval", 'woopress-core'),
      "param_name" => "interval",
      "description" => esc_html__('Interval between slides. In milliseconds. Default: 10000', 'woopress-core'),
      "dependency" => Array('element' => "type", 'value' => array('slider'))
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Speed", 'woopress-core'),
      "param_name" => "speed",
      "description" => esc_html__('Speed between slides. In milliseconds. Default: 900', 'woopress-core'),
      "dependency" => Array('element' => "type", 'value' => array('slider'))
    ),
    array(
      "type" => 'checkbox',
      "heading" => esc_html__("Stop on hover", 'woopress-core' ),
      "param_name" => "stop_on_hover",
      "value" => Array(esc_html__("Yes, please", 'woopress-core' ) => true)
    ),
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Show Control Navigation", 'woopress-core'),
      "param_name" => "navigation",
      "dependency" => Array('element' => "type", 'value' => array('slider')),
      "value" => array(
          "",
          esc_html__("Hide", 'woopress-core') => false,
          esc_html__("Show", 'woopress-core') => true
        )
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Category", 'woopress-core'),
      "param_name" => "category",
      "description" => esc_html__('Display testimonials from category.', 'woopress-core')
    ),
  )

);

vc_map($testimonials_params);