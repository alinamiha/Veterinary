<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');


// **********************************************************************//
// ! Alert Boxes
// **********************************************************************//
function etheme_alert_shortcode($atts, $content = null) {
    $a = shortcode_atts( array(
        'type' => 'success',
        'title' => '',
        'close' => 1
    ), $atts);
    $icon = '';
    switch($a['type']) {
        case 'error':
            $class = 'error';
            $icon = 'times-circle';
        break;
        case 'success':
            $class = 'success';
            $icon = 'check-circle';

        break;
        case 'info':
            $class = 'info';
            $icon = 'info-circle';

        break;
        case 'warning':
            $class = 'warning';
            $icon = 'exclamation-circle';

        break;
        default:
            $class = 'success';
    }
    $closeBtn = '';
    $title = '';
    if($a['close'] == 1){
        $closeBtn = '<span class="close-parent">close</span>';
    }
    if($a['title'] != '') {
        $title = '<span class="h3">' . $a['title'] . '</span><br>';
    }

    return '<p class="' . $class . '">' . $title . do_shortcode($content) . $closeBtn . '</p>';
}