<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');



// **********************************************************************//
// ! etheme promo link
// **********************************************************************//

function et_promo_shortcode($atts) {
    extract(shortcode_atts(array(
    	'color' => '',
        'hover_color' => '',
        'position' => 'left',
        'class' => '',
    ), $atts));

	$rand = 'popup-link-' . rand( 100, 999 );

	$output = '';

	if ( ! empty( $color ) || ! empty( $hover_color ) || ! empty( $position ) ) {

		if ( ! empty( $color ) ) $color =  '.' . $rand . ' a{color:' . esc_html( $color ) . ';}.' . $rand . ':before{color:' . esc_html( $color ) . ';}';

		if ( ! empty( $hover_color ) ) $hover_color =  '.' . $rand . ' a:hover{color:' . esc_html( $hover_color ) . ';}';

		if ( ! empty( $position ) && $position != 'center' ) {
			$position =  '.' . $rand . '{float:' . esc_html( $position ) . ';}';
		} elseif( ! empty( $position ) ){
			$position =  '.' . $rand . '{width: 100%;text-align: center;}';
		} else {
			$position = '';
		}

		$output .= '<style type="text/css">' . $color . $hover_color . $position . '</style>';
	}

	$output .= '<div class="popup_link ' . $rand . '' . esc_html( $class ) . '"><a class="etheme-popup open-click" href="#etheme-popup">' . esc_html__( 'Newsletter', 'woopress-core' ) . '</a></div>';

	return $output;
}



// **********************************************************************//
// ! Register New Element: Etheme Promo Link
// **********************************************************************//

$et_promo = array(
  'name' => 'Etheme Promo Link',
  'base' => 'et_promo',
  'icon' => 'icon-wpb-etheme',
  'category' => 'Eight Theme',
  'params' => array(
  	array(
      "type" => "colorpicker",
      "heading" => esc_html__("Links text color", 'woopress-core'),
      "param_name" => "color",
    ),
    array(
      "type" => "colorpicker",
      "heading" => esc_html__("Links hover text color", 'woopress-core'),
      "param_name" => "hover_color",
    ),
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Position", 'woopress-core'),
      "param_name" => "position",
      "value" => array( esc_html__("Left", 'woopress-core') => "left", esc_html__("Right", 'woopress-core') => "right", esc_html__("Center", 'woopress-core') => "center"),
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Extra class name", 'woopress-core'),
      "param_name" => "class"
    ),
  )

);

vc_map($et_promo);