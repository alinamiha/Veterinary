<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

// **********************************************************************//
// ! etheme links
// **********************************************************************//

function et_links_shortcode($atts) {
    extract(shortcode_atts(array(
        'view'  => 'modal',
        'register' => false,
        'newsletter' => false,
        'color' => '',
        'hover_color' => '',
        'position' => 'left',
        'class' => '',
    ), $atts));

    $rand = 'links-' . rand( 100, 999 );

	$args['newsletter'] = esc_attr( $newsletter );
	$args['class'] = $rand;
	$args['class'] .= ' ' . esc_html( $class );
	$args['register'] = esc_attr( $register );

	ob_start();
	etheme_top_links( $args );
	$output = ob_get_contents();
	ob_end_clean();

	if ( ! empty( $color ) || ! empty( $hover_color ) || ! empty( $position ) ) {

		if ( ! empty( $color ) ) $color =  '.' . $rand . ' a{color:' . esc_html( $color ) . ';}';

		if ( ! empty( $hover_color ) ) $hover_color =  '.' . $rand . ' a:hover{color:' . esc_html( $hover_color ) . ';}';

		if ( ! empty( $position ) && $position != 'center' ) {
			$position =  '.' . $rand . '{float:' . esc_html( $position ) . ';}';
		} elseif( ! empty( $position ) ){
			$position =  '.' . $rand . '{width: 100%;text-align: center;}';
		} else {
			$position = '';
		}

		$output .= '<style type="text/css">' . $color . $hover_color . $position . '</style>';
	}

	return $output;
}


// **********************************************************************//
// ! Register New Element: etheme links
// **********************************************************************//

$et_links = array(
  'name' => 'Etheme Links',
  'base' => 'et_links',
  'icon' => 'icon-wpb-etheme',
  'category' => 'Eight Theme',
  'params' => array(
  	array(
      "type" => "colorpicker",
      "heading" => esc_html__("Links text color", 'woopress-core'),
      "param_name" => "color",
    ),
    array(
      "type" => "colorpicker",
      "heading" => esc_html__("Links hover text color", 'woopress-core'),
      "param_name" => "hover_color",
    ),
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Position", 'woopress-core'),
      "param_name" => "position",
      "value" => array( esc_html__("Left", 'woopress-core') => "left", esc_html__("Right", 'woopress-core') => "right", esc_html__("Center", 'woopress-core') => "center"),
    ),
    array(
      "type" => "checkbox",
      "heading" => esc_html__("Enable Register Link", 'woopress-core'),
      "param_name" => "register",
    ),
    array(
      "type" => "checkbox",
      "heading" => esc_html__("Enable Newsletter Link", 'woopress-core'),
      "param_name" => "newsletter",
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Extra class name", 'woopress-core'),
      "param_name" => "class"
    ),
  )

);

vc_map($et_links);