<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

function etheme_base_url_shortcode(){
    return home_url();
}