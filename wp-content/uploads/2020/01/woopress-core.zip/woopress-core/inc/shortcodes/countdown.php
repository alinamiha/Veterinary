<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');


// **********************************************************************//
// ! Countdown
// **********************************************************************//

function etheme_countdown_shortcode($atts) {
    $a = shortcode_atts(array(
        'class' => '',
        'date' => '31 December 2014 00:00',
        'height' => ''
    ),$atts);

    return '<div class="et-timer" data-final="'.$a['date'].'">
                <div class="time-block">
                    <span class="days">00</span>
                    days
                </div>
                <div class="timer-devider">:</div>
                <div class="time-block">
                    <span class="hours">00</span>
                    hours
                </div>
                <div class="timer-devider">:</div>
                <div class="time-block">
                    <span class="minutes">00</span>
                    minutes
                </div>
                <div class="timer-devider">:</div>
                <div class="time-block">
                    <span class="seconds">00</span>
                    seconds
                </div>
                <div class="clear"></div>
            </div>';
}