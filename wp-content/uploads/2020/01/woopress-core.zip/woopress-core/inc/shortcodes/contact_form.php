<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

// **********************************************************************//
// ! Contact form
// **********************************************************************//


if(!function_exists('et_contact_form')) {
  function et_contact_form($atts) {
    extract( shortcode_atts( array(
      'class' => ''
    ), $atts ) );

    ob_start();
    ?>
        <div id="contactsMsgs"></div>
        <form action="<?php the_permalink(); ?>" method="get" id="contact-form" class="contact-form <?php echo $class; ?>">

            <div class="form-group">
              <p class="form-name">
                <label for="name" class="control-label"><?php esc_html_e('Name and Surname', 'woopress-core') ?> <span class="required">*</span></label>
                <input type="text" name="contact-name" class="required-field form-control" id="contact-name">
              </p>
            </div>

            <div class="form-group">
                <p class="form-name">
                  <label for="contact-email" class="control-label"><?php esc_html_e('Email', 'woopress-core') ?> <span class="required">*</span></label>
                  <input type="text" name="contact-email" class="required-field form-control" id="contact-email">
                </p>
            </div>

            <div class="form-group">
              <p class="form-name">
                <label for="contact-website" class="control-label"><?php esc_html_e('Website', 'woopress-core') ?></label>
                <input type="text" name="contact-website" class="form-control" id="contact-website">
              </p>
            </div>


            <div class="form-group">
              <p class="form-textarea">
                <label for="contact_msg" class="control-label"><?php esc_html_e('Message', 'woopress-core'); ?> <span class="required">*</span></label>
                <textarea name="contact-msg" id="contact-msg" class="required-field form-control" cols="30" rows="7"></textarea>
              </p>
            </div>

            <?php if ( etheme_get_option( 'privacy_contact' ) ): ?>
		        <p class="form-row privacy-policy">
		            <?php echo etheme_get_option( 'privacy_contact' ); ?>
		        </p>
		    <?php endif ?>

            <?php et_display_captcha(); ?>

            <p class="pull-right">
              <input type="hidden" name="contact-submit" id="contact-submit" value="true" >
              <span class="spinner"><?php esc_html_e('Sending...', 'woopress-core') ?></span>
              <button class="btn btn-black big" id="submit" type="submit"><?php esc_html_e('Send message', 'woopress-core') ?></button>
            </p>

            <div class="clearfix"></div>
        </form>
    <?php
    $output = ob_get_contents();
    ob_end_clean();

    return $output;
  }
}