<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

// **********************************************************************//
// ! Project links shortcode
// **********************************************************************//

if ( !function_exists('etheme_project_links') ) {
	function etheme_project_links($atts, $content = null) {
		ob_start();
	    $next_post = get_next_post();
	    $prev_post = get_previous_post();
	   ?>
	        <div class="project-navigation">
	            <?php if(!empty($prev_post)) : ?>
	                <div class="pull-left prev-project">
	                    <a href="<?php echo get_permalink($prev_post->ID); ?>" class="btn border-grey btn-xmedium project-nav"><?php esc_html_e('Previous', 'woopress-core'); ?></a>
	                    <div class="hide-info">
	                        <?php echo get_the_post_thumbnail( $prev_post->ID, apply_filters( 'single_product_small_thumbnail_size', 'shop_thumbnail' ) ); ?>
	                        <span class="price"><?php echo get_the_title($prev_post->ID); ?></span>
	                    </div>
	                </div>
	            <?php endif; ?>
	            <?php if(!empty($next_post)) : ?>
	                <div class="pull-right next-project">
	                    <a href="<?php echo get_permalink($next_post->ID); ?>" class="btn border-grey btn-xmedium project-nav"><?php esc_html_e('Next', 'woopress-core'); ?></a>
	                    <div class="hide-info">
	                        <span class="price"><?php echo get_the_title($next_post->ID); ?></span>
	                        <?php echo get_the_post_thumbnail( $next_post->ID, apply_filters( 'single_product_small_thumbnail_size', 'shop_thumbnail' ) ); ?>
	                    </div>
	                </div>
	            <?php endif; ?>
	        </div>
	    <?php
	    return ob_get_clean();
	}
}