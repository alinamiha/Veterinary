<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');


// **********************************************************************//
// ! etheme top search
// **********************************************************************//

add_shortcode('et_top_search','et_top_search_shortcode');

function et_top_search_shortcode($atts) {
    extract(shortcode_atts(array(
        'view'  => 'modal',
        'class' => '',
    ), $atts));

    $class = esc_html( $class );
    $view = esc_attr( $view );

	ob_start();
	etheme_search_form( $view, $class );
	$output = ob_get_contents();
	ob_end_clean();

	return $output;
}

// **********************************************************************//
		// ! Register New Element: Etheme Search
		// **********************************************************************//

	    $et_top_search = array(
          'name' => 'Etheme Search',
          'base' => 'et_top_search',
          'icon' => 'icon-wpb-etheme',
          'category' => 'Eight Theme',
          'params' => array(
            array(
	          "type" => "dropdown",
	          "heading" => esc_html__("View", 'woopress-core'),
	          "param_name" => "view",
	          "value" => array( esc_html__( 'Popup', 'woopress-core' ) => 'modal', esc_html__( 'Hover', 'woopress-core' ) => 'hover', esc_html__( 'Default', 'woopress-core' ) => 'default'),
	        ),
	        array(
              "type" => "textfield",
              "heading" => esc_html__("Extra class name", 'woopress-core'),
              "param_name" => "class"
            ),
          )
        );

        vc_map($et_top_search);