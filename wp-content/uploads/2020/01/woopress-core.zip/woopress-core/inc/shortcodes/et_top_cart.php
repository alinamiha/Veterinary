<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

// **********************************************************************//
// ! Top cart
// **********************************************************************//

function et_top_cart_shortcode($atts) {
	if ( !class_exists('Woocommerce') ) return false;
    extract(shortcode_atts(array(
		'dropdown' => 'on',
		'color'    => 'dark',
		'position'    => 'right',
		'css'	   => '',
        'class'    => '',
    ), $atts));

    if ( ! empty( $css ) ) {
		$design = explode( "{", $css );
		$design = $design[0];
		$design = explode( ".", $design );
		$design = $design[1];
    } else {
    	$design = '';
    }

    $class = ! empty( $class ) ? ' ' . $class : '';

    $class .= ' style-' . $color;

	$class .= ( $dropdown == 'off' ) ? ' dropdown-disable' : '';

	$class .= ' ' . $design;

	$favicon_badge = etheme_get_option( 'favicon_badge' ) ? ' data-fav-badge="enable"' : '';

	ob_start();
	etheme_cart_items();
	$output = ob_get_contents();
	ob_end_clean();

	$rand = 'shopping-container-' . rand( 100, 999 );

	$style = ( $position == 'center' ) ? '.' . $rand . '{width: 100%;text-align: center; display:inline-block;}.' . $rand . ' .widget_shopping_cart_content{display:inline-block;}.' . $rand . ' .cart-popup-container:before{left: 20px;}.cart-popup-container{right: auto;}' : '';

	$style = (!empty($style)) ? '<style type="text/css">' . $style . '</style>' : '';

	return '<div class="shopping-container ' . $rand . esc_html( $class ) . '" ' . $favicon_badge . '><div class="widget_shopping_cart_content">' . $output . '</div></div>'.$style;

}

if ( function_exists('vc_map') ) {
  // **********************************************************************//
  // ! Register New Element: etheme top cart
  // **********************************************************************//

  $et_top_cart = array(
    'name' => 'Top Cart',
    'base' => 'et_top_cart',
    'icon' => 'icon-wpb-etheme',
    'category' => 'Eight Theme',
    'params' => array(
      array(
        "type" => "dropdown",
        "heading" => esc_html__("Style", 'woopress-core'),
        "param_name" => "color",
        "value" => array( esc_html__( 'Dark', 'woopress-core' ) => 'dark', esc_html__( 'light', 'woopress-core' ) => 'light' ),
      ),
      array(
        "type" => "dropdown",
        "heading" => esc_html__("Enable dropdown", 'woopress-core'),
        "param_name" => "dropdown",
        "value" => array( esc_html__( 'on', 'woopress-core' ) => 'on', esc_html__( 'off', 'woopress-core' ) => 'off'),
      ),
      array(
        "type" => "dropdown",
        "heading" => esc_html__("Position", 'woopress-core'),
        "param_name" => "position",
        "value" => array( esc_html__( "Right", 'woopress-core' ) => "right", esc_html__( "Left", 'woopress-core' ) => "left", esc_html__( "Center", 'woopress-core') => "center" ),
      ),
      array(
        "type" => "textfield",
        "heading" => esc_html__("Extra class name", 'woopress-core'),
        "param_name" => "class"
      ),
      array(
      'type' => 'css_editor',
      'heading' => esc_html__( 'CSS box', 'js_composer' ),
      'param_name' => 'css',
      'group' => esc_html__( 'Design Options', 'js_composer' ),
    ),
    )
  );
  vc_map($et_top_cart);
}