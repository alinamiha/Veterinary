<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

// **********************************************************************//
// ! Banner With mask
// **********************************************************************//

function etheme_banner_shortcode($atts, $content) {
    $image = $mask = '';
    $a = shortcode_atts(array(
        'align'  => 'left',
        'valign'  => 'top',
        'class'  => '',
        'link'  => '',
        'hover'  => '',
        'content'  => '',
        'font_style'  => '',
        'banner_style'  => '',
        'responsive_zoom'  => '',
        'img' => '',
        'img_src' => '',
        'img_size' => '270x170'
    ), $atts);

    $src = '';

    $img_size = explode('x', $a['img_size']);

    $width = isset( $img_size[0] ) ? $img_size[0]: '';
    $height = isset( $img_size[1] ) ? $img_size[1]: '';
	$alt = '';
    if($a['img'] != '') {
        $src = etheme_get_image($a['img'], $width, $height);
        $alt = get_post_meta( $a['img'], '_wp_attachment_image_alt', true );
    }elseif ($a['img_src'] != '') {
        $src = do_shortcode($a['img_src']);
    }

    if ($a['banner_style'] != '') {
      $a['class'] .= ' style-'.$a['banner_style'];
    }

    if ($a['align'] != '') {
      $a['class'] .= ' align-'.$a['align'];
    }

    if ($a['valign'] != '') {
      $a['class'] .= ' valign-'.$a['valign'];
    }

    if($a['responsive_zoom']) {
    	$a['class'] .= ' responsive-fonts';
    }

    $onclick = '';
    $link_array = array();
    if($a['link'] != '') {
    	foreach (explode('|', $a['link']) as $key ) {
	  		$array = explode(":", $key );
	  		if ( !empty($array[0]) && !empty($array[1]) ) {
	  			$link_array[$array[0]] = $array[1];
	  		}
	  	}
    	$url = '#';
    	$a['class'] .= ' cursor-pointer';
    	if ( !empty($link_array['url']) ) {
    	$url = urldecode($link_array['url']); }
    	if (  !empty($link_array['target']) && array_key_exists('target', $link_array) ) {
    		$onclick = 'onclick="window.open(\''. $url.'\',\'_blank\')"';
	  	}
	  	else {
    		$onclick = 'onclick="window.location=\''.$url.'\'"';
    	}
    }

    return '<div class="banner '.$a['class'].' banner-font-'.$a['font_style'].' hover-'.$a['hover'].'" '.$onclick.'><div class="banner-content"><div class="banner-inner">'.do_shortcode($content).'</div></div><img src="'.$src.'" alt="'.$alt.'"/></div>';
}



// **********************************************************************//
	    // ! Register New Element: Banner with mask
	    // **********************************************************************//

	    $banner_params = array(
	      'name' => 'Banner',
	      'base' => 'banner',
	      'icon' => 'icon-wpb-etheme',
	      'category' => 'Eight Theme',
	      'params' => array(
	        array(
	          'type' => 'attach_image',
	          "heading" => esc_html__("Banner Image", 'woopress-core'),
	          "param_name" => "img"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Banner size", 'woopress-core'),
	          "param_name" => "img_size",
	          "description" => esc_html__("Enter image size. Example in pixels: 200x100 (Width x Height).", 'woopress-core')
	        ),
	        array(
	          "type" => "vc_link",
	          "heading" => esc_html__("Link", 'woopress-core'),
	          "param_name" => "link",
	        ),
	        array(
	          "type" => "textarea_html",
	          "holder" => "div",
	          "heading" => "Banner Mask Text",
	          "param_name" => "content",
	          "value" => "Some promo text"
	        ),
	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Horizontal align", 'woopress-core'),
	          "param_name" => "align",
	          "value" => array( "", esc_html__("Left", 'woopress-core') => "left", esc_html__("Center", 'woopress-core') => "center", esc_html__("Right", 'woopress-core') => "right")
	        ),
	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Vertical align", 'woopress-core'),
	          "param_name" => "valign",
	          "value" => array( esc_html__("Top", 'woopress-core') => "top", esc_html__("Middle", 'woopress-core') => "middle", esc_html__("Bottom", 'woopress-core') => "bottom")
	        ),
	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Hover effect", 'woopress-core'),
	          "param_name" => "hover",
	          "value" => array( "", esc_html__("zoom", 'woopress-core') => "zoom", esc_html__("fade", 'woopress-core') => "fade")
	        ),
		    array(
		      "type" => 'checkbox',
		      "heading" => esc_html__("Responsive fonts", 'woopress-core'),
		      "param_name" => "responsive_zoom",
		      "value" => Array(esc_html__("Yes, please", 'woopress-core') => 'yes')
		    ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Extra Class", 'woopress-core'),
	          "param_name" => "class",
	          "description" => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'woopress-core')
	        )
	      )

	    );

	    vc_map($banner_params);