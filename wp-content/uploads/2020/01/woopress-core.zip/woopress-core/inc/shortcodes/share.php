<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

// **********************************************************************//
// ! Share This Product
// **********************************************************************//

if(!function_exists('etheme_share_shortcode')) {
	function etheme_share_shortcode($atts, $content = null) {
		extract(shortcode_atts(array(
			'title'  => '',
			'text' => '',
			'tooltip' => 1,
	        'twitter' => 1,
	        'facebook' => 1,
	        'pinterest' => 1,
	        'google' => 1,
	        'mail' => 1,
			'class' => ''
		), $atts));
		wp_reset_query();
		global $post;
		if(!isset($post->ID)) return;
	    $html = '';
		$permalink = get_permalink($post->ID);
		$tooltip_class = '';
		if($tooltip) {
			$tooltip_class = 'title-toolip';
		}
		$image =  etheme_get_image( get_post_thumbnail_id($post->ID), 150,150,false);
		$post_title = rawurlencode(get_the_title($post->ID));
		if($title) $html .= '<span class="share-title">'.$title.'</span>';
	    $html .= '
	        <ul class="menu-social-icons '.$class.'">
	    ';
	    if($twitter == 1) {
	        $html .= '
	                <li>
	                    <a href="https://twitter.com/share?url='.$permalink.'&text='.$post_title.'" class="'.$tooltip_class.'" title="'.__('Twitter', 'woopress-core').'" target="_blank">
	                        <i class="ico-twitter"></i>
	                        <svg width="38" height="38" xmlns="http://www.w3.org/2000/svg" class="circle">
	                                <circle cx="19" cy="19" r="18" fill="rgba(255,255,255,0)" stroke="#000000"></circle>
	                        </svg>
	                    </a>
	                </li>
	        ';
	    }
	    if($facebook == 1) {
	        $html .= '
	                <li>
	                    <a href="http://www.facebook.com/sharer.php?u='.$permalink.'" class="'.$tooltip_class.'" title="'.__('Facebook', 'woopress-core').'" target="_blank">
	                        <i class="ico-facebook"></i>
	                        <svg width="38" height="38" xmlns="http://www.w3.org/2000/svg" class="circle">
	                                <circle cx="19" cy="19" r="18" fill="rgba(255,255,255,0)" stroke="#000000"></circle>
	                        </svg>
	                    </a>
	                </li>
	        ';
	    }

	    if($pinterest == 1) {
	        $html .= '
	                <li>
	                    <a href="http://pinterest.com/pin/create/button/?url='.$permalink.'&amp;media='.$image.'&amp;description='.$post_title.'" class="'.$tooltip_class.'" title="'.__('Pinterest', 'woopress-core').'" target="_blank">
	                        <i class="ico-pinterest"></i>
	                        <svg width="38" height="38" xmlns="http://www.w3.org/2000/svg" class="circle">
	                                <circle cx="19" cy="19" r="18" fill="rgba(255,255,255,0)" stroke="#000000"></circle>
	                        </svg>
	                    </a>
	                </li>
	        ';
	    }

	    if($google == 1) {
	        $html .= '
	                <li>
	                    <a href="http://plus.google.com/share?url='.$permalink.'&title='.$text.'" class="'.$tooltip_class.'" title="'.__('Google +', 'woopress-core').'" target="_blank">
	                        <i class="ico-google-plus"></i>
	                        <svg width="38" height="38" xmlns="http://www.w3.org/2000/svg" class="circle">
	                                <circle cx="19" cy="19" r="18" fill="rgba(255,255,255,0)" stroke="#000000"></circle>
	                        </svg>
	                    </a>
	                </li>
	        ';
	    }

	    if($mail == 1) {
	        $html .= '
	                <li>
	                    <a href="mailto:enteryour@addresshere.com?subject='.$post_title.'&amp;body=Check%20this%20out:%20'.$permalink.'" class="'.$tooltip_class.'" title="'.__('Mail to friend', 'woopress-core').'" target="_blank">
	                        <i class="ico-envelope"></i>
	                        <svg width="38" height="38" xmlns="http://www.w3.org/2000/svg" class="circle">
	                                <circle cx="19" cy="19" r="18" fill="rgba(255,255,255,0)" stroke="#000000"></circle>
	                        </svg>
	                    </a>
	                </li>
	        ';
	    }

	    $html .= '
	        </ul>
	    ';
		return $html;
	}
}