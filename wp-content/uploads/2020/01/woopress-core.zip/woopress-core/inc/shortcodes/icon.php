<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');



// **********************************************************************//
// ! Icon
// **********************************************************************//

function etheme_icon_shortcode($atts, $content = null) {
$a = shortcode_atts(array(
        'name' => 'circle-blank',
        'size' => '',
        'style' => '',
        'color' => '',
        'hover' => 0,
        'class' => ''
    ), $atts);

    if($a['hover'] == 1 ) {
        $a['name'] .= ' hover-icon';
    }

    return '<i class="fa fa-'.$a['name'].' ' . $a['class'] . '" style="color:'.$a['color'].'; font-size:'.$a['size'].'px; '.$a['style'].'"></i>';
}



	    // **********************************************************************//
	    // ! Register New Element: Icon
	    // **********************************************************************//

	    $icon_params = array(
	      'name' => 'Awesome Icon',
	      'base' => 'icon',
	      'icon' => 'icon-wpb-etheme',
	      'category' => 'Eight Theme',
	      'params' => array(
	        array(
	          'type' => 'icon',
	          "heading" => esc_html__("Icon", 'woopress-core'),
	          "param_name" => "name"
	        ),
	        array(
	          'type' => 'textfield',
	          "heading" => esc_html__("Size", 'woopress-core'),
	          "param_name" => "size",
	          "description" => esc_html__('For example: 64', 'woopress-core')
	        ),
	        array(
	          'type' => 'colorpicker',
	          "heading" => esc_html__("Color", 'woopress-core'),
	          "param_name" => "color"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Extra Class", 'woopress-core'),
	          "param_name" => "class",
	          "description" => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'woopress-core')
	        )
	      )

	    );

	    //vc_map($icon_params);