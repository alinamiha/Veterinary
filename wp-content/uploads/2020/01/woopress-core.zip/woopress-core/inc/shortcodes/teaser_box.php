<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');

function etheme_teaser_box_shortcodes($atts, $content=null){
    extract(shortcode_atts(array(
        'title' => '',
        'heading' => '4',
        'img' => '',
        'img_src' => '',
        'img_size' => '270x170',
        'style' => '',
        'class' => ''
    ), $atts));

    $src = '';

    $img_size = explode('x', $img_size);

    $width = $img_size[0];
    $height = $img_size[1];

    if($img != '') {
        $src = etheme_get_image($img, $width, $height);
    }elseif ($img_src != '') {
        $src = do_shortcode($img_src);
    }

    if($title != '') {
	    $title = '<h'.$heading.' class="text-center"><span>'.$title.'</span></h'.$heading.'><hr class="horizontal-break-alt"/>';
    }

    if($src != '') {
	    $img = '<img src="'.$src.'">';
    }

    if($style != '') {
	    $class .= ' style-'.$style;
    }

    return '<div class="teaser-box '.$class.'"><div>'. $title . $img . do_shortcode($content) .'</div></div>';

}


// **********************************************************************//
	    // ! Register New Element: Teaser Box
	    // **********************************************************************//

	    $teaser_box_params = array(
	      'name' => 'Teaser Box',
	      'base' => 'teaser_box',
	      'icon' => 'icon-wpb-etheme',
	      'category' => 'Eight Theme',
	      'params' => array(
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Title", 'woopress-core'),
	          "param_name" => "title"
	        ),
	        array(
	          'type' => 'attach_image',
	          "heading" => esc_html__("Image", 'woopress-core'),
	          "param_name" => "img"
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Image size", 'woopress-core'),
	          "param_name" => "img_size",
	          "description" => esc_html__("Enter image size. Example in pixels: 200x100 (Width x Height).", 'woopress-core')
	        ),
	        array(
	          "type" => "textarea_html",
	          'admin_label' => true,
	          "heading" => esc_html__("Text", 'woopress-core'),
	          "param_name" => "content",
	          "value" => esc_html__("Click edit button to change this text.", 'woopress-core'),
	          "description" => esc_html__("Enter your content.", 'woopress-core')
	        ),
	        array(
	          "type" => "dropdown",
	          "heading" => esc_html__("Style", 'woopress-core'),
	          "param_name" => "style",
	          "value" => array( esc_html__("Default", 'woopress-core') => 'default', esc_html__("Bordered", 'woopress-core') => 'bordered')
	        ),
	        array(
	          "type" => "textfield",
	          "heading" => esc_html__("Extra Class", 'woopress-core'),
	          "param_name" => "class",
	          "description" => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'woopress-core')
	        )
	      )

	    );

	    vc_map($teaser_box_params);