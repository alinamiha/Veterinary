<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');


// **********************************************************************//
// ! Recent posts widget shortcode
// **********************************************************************//

function etheme_recent_posts_widget_shortcode($atts, $content = null) {
    $a = shortcode_atts(array(
        'title' => '',
        'number' => 5,
        'slider' => 0
    ),$atts);

    $widget = new Etheme_Recent_Posts_Widget();

    $args = array(
        'before_widget' => '<div class="sidebar-widget etheme_widget_recent_entries">',
        'after_widget' => '</div><!-- //sidebar-widget -->',
        'before_title' => '<h4 class="widget-title">',
        'after_title' => '</h4>',
        'widget_id' => 'etheme_widget_recent_entries',
    );
    $instance = array(
        'title' => $a['title'],
        'number' => $a['number'],
        'slider' => $a['slider']
    );

    ob_start();
    $widget->widget($args, $instance);
    $output = ob_get_contents();
    ob_end_clean();

    return $output;
}


// **********************************************************************//
// ! Register New Element: Recent Posts Widget
// **********************************************************************//

$recent_posts_params = array(
  'name' => 'Recent posts widget',
  'base' => 'et_recent_posts_widget',
  'icon' => 'icon-wpb-etheme',
  'category' => 'Eight Theme',
  'params' => array(
    array(
      'type' => 'textfield',
      "heading" => esc_html__("Widget title", 'woopress-core'),
      "param_name" => "title",
      "description" => esc_html__("What text use as a widget title. Leave blank if no title is needed.", 'woopress-core')
    ),
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Enable slider", 'woopress-core'),
      "param_name" => "slider",
      "value" => array(
          "",
          esc_html__("Enable", 'woopress-core') => 1,
          esc_html__("Disable", 'woopress-core') => 0
        )
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Limit", 'woopress-core'),
      "param_name" => "number",
      "description" => esc_html__('How many testimonials to show? Enter number.', 'woopress-core')
    )
  )

);

vc_map($recent_posts_params);