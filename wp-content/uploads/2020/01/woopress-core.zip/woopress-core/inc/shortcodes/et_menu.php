<?php  if ( ! defined('ABSPATH')) exit('No direct script access allowed');



// **********************************************************************//
// ! etheme menu
// **********************************************************************//

function et_menu_shortcode($atts) {
    extract(shortcode_atts(array(
    	'position' => 'left',
    	'mobile'   => '',
        'class'    => '',
    ), $atts));

  	$rand = 'shortcode-menu-' . rand( 100, 999 );
    $class = ' shortcode-menu ' . esc_html( $class );
    $class .= $rand;

    if ( $mobile == 'on' ) {
     	$output = '
     		<div class="navbar' . $class . '" role="navigation">
				<div class="container-fluid">
					<div id="st-trigger-effects" class="column">
						<button data-effect="mobile-menu-block" class="menu-icon"></button>
					</div>
				</div>
			</div>
		';
		return $output;
    }

	ob_start();
	et_get_main_menu( 'main-menu', $class );
	$output = ob_get_contents();
	ob_end_clean();

	if ( $position == 'center' ) {
		$output .= '<style type="text/css">.' . $rand . ' .menu{display:inline-block;}.' . $rand . '{text-align:center;}</style>';
	} else {
		$output .= '<style type="text/css">.' . $rand . '{float:' . $position . ';}</style>';
	}

	return $output;
}

if ( function_exists('vc_map') ) {
	// **********************************************************************//
	// ! Register New Element: etheme menu
	// **********************************************************************//

	$et_menu = array(
	  'name' => 'Etheme Main Menu',
	  'base' => 'et_menu',
	  'icon' => 'icon-wpb-etheme',
	  'category' => 'Eight Theme',
	  'params' => array(
	  	 array(
			"type" => "dropdown",
			"heading" => esc_html__("Position", 'woopress-core'),
			"param_name" => "position",
			"value" => array( esc_html__("Left", 'woopress-core') => "left", esc_html__("Right", 'woopress-core') => "right", esc_html__("Center", 'woopress-core') => "center"),
	    ),
	    array(
			"type" => 'checkbox',
			"heading" => esc_html__("Mobile Trigger", 'woopress-core' ),
			"param_name" => "mobile",
			"value" => Array(esc_html__("Yes, please", 'woopress-core' ) => 'on')
	    ),
	    array(
			"type" => "textfield",
			"heading" => esc_html__( "Extra class name", 'woopress-core' ),
			"param_name" => "class"
	    ),
	  )
	);
	vc_map($et_menu);
}