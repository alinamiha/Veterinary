<?php  defined('ABSPATH') || exit( 'No direct script access allowed' );
/**
 * Chack plugin compatybility.
 * 
 * @since 1.0.0
 * @version 1.0.1
 */

function woopress_plugin_compatibility(){

    if ( get_option( 'woopress_core_force_stop', false ) ) {
        $html = '<div class="et-message et-error error">';
            $html .= '<p>' . esc_html__( 'Attention!', 'woopress-core' ) . '</p>';
            $html .= '<p>' . esc_html__( 'WooPress Core plugin requires the following theme: Woopress v6.0.1 or higher.', 'woopress-core' ) . '</p>';
        $html .= '</div>';

        add_filter( 'admin_notices', function($msg) use ($html){ echo $html; } );
        
    }

    if ( @is_child_theme() ) {
        $theme = wp_get_theme(get_option('template'));
    } else {
        $theme = wp_get_theme();
    }

    if ( version_compare( $theme->version, '6.0.1', '<' ) ) {

        $html = '<div class="et-message et-error error">';
            $html .= '<p>' . esc_html__( 'Attention!', 'woopress-core' ) . '</p>';
            $html .= '<p>' . esc_html__( 'WooPress Core plugin requires the following theme: Woopress v6.0.1 or higher.', 'woopress-core' ) . '</p>';
        $html .= '</div>';

        add_filter( 'admin_notices', function($msg) use ($html){ echo $html; } );

        return false;
    }

	$plugins = array();

    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

    if ( is_plugin_active( 'legenda-core/legenda-core.php' ) ) {
        $plugins[] = 'Legenda core';
    } 

    if ( is_plugin_active( 'royal-core/royal-core.php' ) ) {
        $plugins[] = 'royal core';
    } 

    if ( is_plugin_active( 'classico-core-plugin/post-types.php' ) ) {
        $plugins[] = 'Classico core';
    } 

    if ( is_plugin_active( 'et-core-plugin/et-core-plugin.php' ) ) {
        $plugins[] = 'XStore core';
    } 

    if ( count( $plugins ) ) {
        $html = '<div class="et-message et-error error">';
            $html .= '<p>' . esc_html__( 'Attention!', 'woopress-core' ) . '</p>';
            $html .= '<p>';
                $html .= '<strong>';
                    $html .= '<span>' . esc_html__( 'WooPress Core plugin conflicts with the following plugins: ', 'woopress-core' ) . '</span>';
                    $_i = 0;
                    foreach ( $plugins as $value ) {
                        $_i++;
                        if ( $_i == count( $plugins ) ) {
                            $html .= '<span>' . $value . '</span>.';
                        } else {
                            $html .= '<span>' . $value . '</span>, ';
                        }
                    }
                $html .= '</strong>';
            $html .= '</p>';
            $html .= '<p>' . esc_html__( 'Keep enabled only plugin that comes bundled with activated theme.', 'woopress-core' ) . '</p>';
        $html .= '</div>';

        add_filter( 'admin_notices', function($msg) use ($html){ echo $html; } );

        return false;
    }

	return true;
}