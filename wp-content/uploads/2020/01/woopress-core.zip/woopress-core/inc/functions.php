<?php  defined('ABSPATH') || exit( 'No direct script access allowed' );


// **********************************************************************//
// ! Twitter API functions
// **********************************************************************//
function etheme_capture_tweets($consumer_key,$consumer_secret,$user_token,$user_secret,$user, $count) {

    $connection = getConnectionWithAccessToken($consumer_key,$consumer_secret,$user_token, $user_secret);
    $params = array(
        'screen_name' => $user,
        'count' => $count
    );

    $content = $connection->get("statuses/user_timeline",$params);

    return json_encode($content);
}

function getConnectionWithAccessToken($consumer_key,$consumer_secret,$oauth_token, $oauth_token_secret) {
    $connection = new TwitterOAuth($consumer_key, $consumer_secret, $oauth_token, $oauth_token_secret);
    return $connection;
}


function etheme_tweet_linkify($tweet) {
    $tweet = preg_replace("#(^|[\n ])([\w]+?://[\w]+[^ \"\n\r\t< ]*)#", "\\1<a href=\"\\2\" target=\"_blank\">\\2</a>", $tweet);
    $tweet = preg_replace("#(^|[\n ])((www|ftp)\.[^ \"\t\n\r< ]*)#", "\\1<a href=\"http://\\2\" target=\"_blank\">\\2</a>", $tweet);
    $tweet = preg_replace("/@(\w+)/", "<a href=\"http://www.twitter.com/\\1\" target=\"_blank\">@\\1</a>", $tweet);
    $tweet = preg_replace("/#(\w+)/", "<a href=\"http://search.twitter.com/search?q=\\1\" target=\"_blank\">#\\1</a>", $tweet);
    return $tweet;
}

function etheme_store_tweets($file, $tweets) {
    if ( !file_exists($file) ) return false;
    ob_start(); // turn on the output buffering
    $fo = fopen($file, 'w'); // opens for writing only or will create if it's not there
    if (!$fo) return etheme_print_tweet_error(error_get_last());
    $fr = fwrite($fo, $tweets); // writes to the file what was grabbed from the previous function
    if (!$fr) return etheme_print_tweet_error(error_get_last());
    fclose($fo); // closes
    ob_end_flush(); // finishes and flushes the output buffer;
}

function etheme_pick_tweets($file) {
    if ( !file_exists($file) ) return false;
    ob_start(); // turn on the output buffering
    $fo = fopen($file, 'r'); // opens for reading only
    if (!$fo) return etheme_print_tweet_error(error_get_last());
    $fr = fread($fo, filesize($file));
    if (!$fr) return etheme_print_tweet_error(error_get_last());
    fclose($fo);
    ob_end_flush();
    return $fr;
}

function etheme_print_tweet_error($errorArray) {
    return '<p class="eth-error">' . esc_html__('Error: ', 'woopress-core' ) . $errorArray['message'] . esc_html__('in ', 'woopress-core' ) . $errorArray['file'] . esc_html__( 'on line ', 'woopress-core' ) . $errorArray['line'] . '</p>';

}

function etheme_twitter_cache_enabled(){
    return true;
}

function etheme_print_tweets($consumer_key,$consumer_secret,$user_token,$user_secret,$user, $count, $cachetime=50) {
    if(etheme_twitter_cache_enabled()){
        //setting the location to cache file
        $cachefile = ETHEME_CODE_DIR . '/cache/twitterCache.json';

        // the file exitsts but is outdated, update the cache file
        if (file_exists($cachefile) && ( time() - $cachetime > filemtime($cachefile)) && filesize($cachefile) > 0) {
            //capturing fresh tweets
            $tweets = etheme_capture_tweets($consumer_key,$consumer_secret,$user_token,$user_secret,$user, $count);
            $tweets_decoded = json_decode($tweets, true);
            //if get error while loading fresh tweets - load outdated file
            if(isset($tweets_decoded['error'])) {
                $tweets = etheme_pick_tweets($cachefile);
            }
            //else store fresh tweets to cache
            else
                etheme_store_tweets($cachefile, $tweets);
        }
        //file doesn't exist or is empty, create new cache file
        elseif (!file_exists($cachefile) || filesize($cachefile) == 0) {
            $tweets = etheme_capture_tweets($consumer_key,$consumer_secret,$user_token,$user_secret,$user, $count);
            $tweets_decoded = json_decode($tweets, true);
            //if request fails, and there is no old cache file - print error
            if(isset($tweets_decoded['error'])) {
                return 'Error: ' . $tweets_decoded['error'];
            }
            //make new cache file with request results
            else {
                etheme_store_tweets($cachefile, $tweets);
            }
        }
        //file exists and is fresh
        //load the cache file
        else {
           $tweets = etheme_pick_tweets($cachefile);
        }
    } else{
       $tweets = etheme_capture_tweets($consumer_key,$consumer_secret,$user_token,$user_secret,$user, $count);
    }

    $tweets = json_decode($tweets, true);
    $html = '<ul class="twitter-list">';

    foreach ($tweets as $tweet) {
        $html .= '<li class="lastItem firstItem"><div class="media"><i class="pull-left fa fa-twitter"></i><div class="media-body">' . $tweet['text'] . '</div></div></li>';
    }
    $html .= '</ul>';
    $html = etheme_tweet_linkify($html);
    return $html;
}

if ( ! function_exists( 'etheme_mail' ) ) {
    function etheme_mail( $reciever_email, $subject, $body, $headers ){
        return wp_mail( $reciever_email, $subject, $body, $headers );
    }
}


// **********************************************************************//
// ! QR Code generation
// **********************************************************************//
if(!function_exists('generate_qr_code')) {
    function generate_qr_code($text='QR Code', $title = 'QR Code', $size = 128, $class = '', $self_link = false, $lightbox = false ) {
        if($self_link) {
            global $wp;
            $text = @$_SERVER['HTTPS'] == 'on' ? 'https://' : 'http://';
            if ( $_SERVER['SERVER_PORT'] != '80' )
                $text .= $_SERVER['SERVER_NAME'] . ':' . $_SERVER['SERVER_PORT'] . $_SERVER['REQUEST_URI'];
            else
                $text .= $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
        }
        $image = 'https://chart.googleapis.com/chart?chs=' . $size . 'x' . $size . '&cht=qr&chld=H|1&chl=' . $text;

        if($lightbox) {
            $class .= ' qr-lighbox';
            $output = '<a href="'.$image.'" rel="lightbox" class="'.$class.'">'.$title.'</a>';
        } else{
            $class .= ' qr-image';
            $output = '<img src="'.$image.'"  class="'.$class.'" />';
        }

        return $output;
    }
}





function et_dequeue_ult_scripts() {
    $force_ultimate_styles = etheme_get_option('force_addons_css');
    if ( $force_ultimate_styles ) {
        wp_dequeue_script( 'jquery_ultimate_expsection' );
        wp_deregister_script( 'jquery_ultimate_expsection' );
    }
}
add_action( 'wp_print_scripts', 'et_dequeue_ult_scripts' );


// Remove query string from static files
function remove_cssjs_ver( $src ) {

    // Do not do it for revslider and essential-grid.
    if ( strpos( $src, 'revslider' ) || strpos( $src, 'essential-grid' ) ) return esc_url( $src );

    if( strpos( $src, '?ver=' ) )
        $src = remove_query_arg( 'ver', $src );
    return esc_url($src);
}

add_filter( 'style_loader_src', 'remove_cssjs_ver', 10, 2 );
add_filter( 'script_loader_src', 'remove_cssjs_ver', 10, 2 );