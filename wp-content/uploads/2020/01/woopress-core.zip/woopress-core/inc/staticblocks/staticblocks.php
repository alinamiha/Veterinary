<?php 



// **********************************************************************//
// ! Custom Static Blocks Post Type
// **********************************************************************//

add_action('init', 'et_register_static_blocks');
add_filter( 'manage_staticblocks_posts_columns', 'et_staticblocks_columns' );
add_action( 'manage_staticblocks_posts_custom_column', 'et_staticblocks_columns_val', 10, 2 );

if(!function_exists('et_register_static_blocks')) {
    function et_register_static_blocks() {
            $labels = array(
                'name' => _x( 'Static Blocks', 'post type general name', 'woopress-core' ),
                'singular_name' => _x( 'Block', 'post type singular name', 'woopress-core' ),
                'add_new' => _x( 'Add New', 'static block', 'woopress-core' ),
                'add_new_item' => sprintf( esc_html__( 'Add New %s', 'woopress-core' ), esc_html__( 'Static Blocks', 'woopress-core' ) ),
                'edit_item' => sprintf( esc_html__( 'Edit %s', 'woopress-core' ), esc_html__( 'Static Blocks', 'woopress-core' ) ),
                'new_item' => sprintf( esc_html__( 'New %s', 'woopress-core' ), esc_html__( 'Static Blocks', 'woopress-core' ) ),
                'all_items' => sprintf( esc_html__( 'All %s', 'woopress-core' ), esc_html__( 'Static Blocks', 'woopress-core' ) ),
                'view_item' => sprintf( esc_html__( 'View %s', 'woopress-core' ), esc_html__( 'Static Blocks', 'woopress-core' ) ),
                'search_items' => sprintf( esc_html__( 'Search %a', 'woopress-core' ), esc_html__( 'Static Blocks', 'woopress-core' ) ),
                'not_found' =>  sprintf( esc_html__( 'No %s Found', 'woopress-core' ), esc_html__( 'Static Blocks', 'woopress-core' ) ),
                'not_found_in_trash' => sprintf( esc_html__( 'No %s Found In Trash', 'woopress-core' ), esc_html__( 'Static Blocks', 'woopress-core' ) ),
                'parent_item_colon' => '',
                'menu_name' => esc_html__( 'Static Blocks', 'woopress-core' )

            );
            $args = array(
                'labels' => $labels,
                'public' => true,
                'publicly_queryable' => true,
                'show_ui' => true,
                'show_in_menu' => true,
                'query_var' => true,
                'rewrite' => array( 'slug' => 'staticblocks' ),
                'capability_type' => 'post',
                'has_archive' => 'staticblocks',
                'hierarchical' => false,
                'supports' => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
                'menu_position' => 8,
                'show_in_rest' => true
            );
            register_post_type( 'staticblocks', $args );
    }
}

if ( !function_exists('et_staticblocks_columns') ) { 
    function et_staticblocks_columns($defaults) {
        return array(
            'cb'               => '<input type="checkbox" />',
            'title'            => esc_html__( 'Title', 'woopress-core' ),
            'shortcode_column' => esc_html__( 'Shortcode', 'woopress-core' ),
            'date'             => esc_html__( 'Date', 'woopress-core' ),
        );
    }
}
 
if ( !function_exists('et_staticblocks_columns_val') ) {    
    function et_staticblocks_columns_val($column_name, $post_ID) {
       if ($column_name == 'shortcode_column') {
            echo '[block id="'.$post_ID.'"]';
       }
    }
}