<?php  defined('ABSPATH') || exit( 'No direct script access allowed' );

/**
 * Create options html for etheme_background cmb2 field
 * @since   6.0.0
 * @version 1.0.0
 */
function et_create_select( $array, $selected = false ){
    $html = '';
    foreach ( $array as $key => $value ) {
        $html .= '<option value="' . $key . '" ' . selected( $selected, $key, false ) . '>' . $value . '</option>';
    }
    return $html;
}

/**
 * Add etheme_background cmb2 field
 * @since   6.0.0
 * @version 1.0.0
 */
function cmb2_render_etheme_background_field_callback( $field, $value, $object_id, $object_type, $field_type ) {
    $value = wp_parse_args( $value, array(
        'background-size'       => '',
        'background-repeat'     => '',
        'background-color' 		=> '',
        'background-image' 		=> '',
        'background-attachment' => '',
        'background-position' 	=> ''
    ) );
    ?>

    <div>
        <p>
            <label for="<?php echo $field_type->_id( '_background-color' ); ?>'"><?php esc_html_e( 'Background color', 'woopress-core' ); ?></label>
        </p>
        <?php 
            echo $field_type->input( array(
                'name'  => $field_type->_name( '[background-color]' ),
                'id'    => $field_type->_id( '_background-color' ),
                'value' => $value['background-color'],
                'class' => 'cmb2-colorpicker'
            ) );
            ?>
    </div>
    <div>
        <p>
            <label for="<?php echo $field_type->_id( '_background-size' ); ?>'"><?php esc_html_e( 'Background size', 'woopress-core' ); ?></label>
        </p>
        <?php echo $field_type->input( array(
            'name'  => $field_type->_name( '[background-size]' ),
            'id'    => $field_type->_id( '_background-size' ),
            'value' => $value['background-size'],
        ) ); ?>
    </div>
    <div>
        <p>
            <label for="<?php echo $field_type->_id( '_background-repeat' ); ?>'"><?php esc_html_e( 'Background repeat', 'woopress-core' ); ?></label>
        </p>
        <?php echo $field_type->select( array(
            'name'    => $field_type->_name( '[background-repeat]' ),
            'id'      => $field_type->_id( '_background-repeat' ),
            'options' => et_create_select( array(
                ''         => esc_html__( 'background-repeat', 'woopress-core' ),
                'repeat'   => esc_html__( 'Repeat All', 'woopress-core' ),
                'repeat-x' => esc_html__( 'Repeat Horizontally', 'woopress-core' ),
                'repeat-y' => esc_html__( 'Repeat Vertically', 'woopress-core' ),
                'inherit'  => esc_html__( 'Inherit', 'woopress-core' )
            ) ),
        ) ); ?>
    </div>
    <div>
        <p>
            <label for="<?php echo $field_type->_id( '_background-attachment' ); ?>'"><?php esc_html_e( 'Background attachment', 'woopress-core' ); ?></label>
        </p>
        <?php echo $field_type->select( array(
            'name'    => $field_type->_name( '[background-attachment]' ),
            'id'      => $field_type->_id( '_background-attachment' ),
            'options' => et_create_select( array(
                ''        => esc_html__( 'background-attachment', 'woopress-core' ),
                'fixed'   => esc_html__( 'Fixed', 'woopress-core' ),
                'scroll'  => esc_html__( 'Scroll', 'woopress-core' ),
                'inherit' => esc_html__( 'Inherit', 'woopress-core' )
            ) ),
        ) ); ?>
    </div>
    <div>
        <p>
            <label for="<?php echo $field_type->_id( '_background-position' ); ?>'"><?php esc_html_e( 'Background position', 'woopress-core' ); ?></label>
        </p>
        <?php echo $field_type->select( array(
            'name'    => $field_type->_name( '[background-position]' ),
            'id'      => $field_type->_id( '_background-position' ),
            'options' => et_create_select( array(
                ''              => esc_html__( 'background-position', 'woopress-core' ),
                'left top'      => esc_html__( 'Left Top', 'woopress-core' ),
                'left center'   => esc_html__( 'Left Center', 'woopress-core' ),
                'left bottom'   => esc_html__( 'Left Bottom', 'woopress-core' ),
                'center top'    => esc_html__( 'Center Top', 'woopress-core' ),
                'center center' => esc_html__( 'Center Center', 'woopress-core' ),
                'center bottom' => esc_html__( 'Center Bottom', 'woopress-core' ),
                'right top'     => esc_html__( 'Right Top', 'woopress-core' ),
                'right center'  => esc_html__( 'Right Center', 'woopress-core' ),
                'right bottom'  => esc_html__( 'Right Bottom', 'woopress-core' )
            ) ),
        ) ); ?>
    </div>
    <div>
        <p>
            <label for="<?php echo $field_type->_id( '_background-image' ); ?>'"><?php esc_html_e( 'Background image', 'woopress-core' ); ?></label>
        </p>
        <?php echo $field_type->file( array(
            'name'  => $field_type->_name( '[background-image]' ),
            'id'    => $field_type->_id( '_background-image' ),
            'value' => $value['background-image'],
        ) ); ?>
    </div>
    <br class="clear">
    <?php
}
add_filter( 'cmb2_render_etheme_background', 'cmb2_render_etheme_background_field_callback', 10, 5 );


// **********************************************************************//
// ! Product Video
// **********************************************************************//

add_action('admin_init', 'et_product_meta_boxes');

function et_product_meta_boxes() {
    add_meta_box( 'woocommerce-product-videos', esc_html__( 'Product Video', 'woopress-core' ), 'et_woocommerce_product_video_box', 'product', 'side' );
}

if(!function_exists('et_woocommerce_product_video_box')) {
    function et_woocommerce_product_video_box() {
        global $post;
        ?>
        <div id="product_video_container">
            <?php esc_html_e('Upload your Video in 3 formats: MP4, OGG and WEBM', 'woopress-core') ?>
            <ul class="product_video">
                <?php

                    $product_video_code = get_post_meta( $post->ID, '_product_video_code', true );


                    if ( metadata_exists( 'post', $post->ID, '_product_video_gallery' ) ) {
                        $product_image_gallery = get_post_meta( $post->ID, '_product_video_gallery', true );
                    }

                    $video_attachments = false;

                    if(isset($product_image_gallery) && $product_image_gallery != '') {
                        $video_attachments = get_posts( array(
                            'post_type' => 'attachment',
                            'include' => $product_image_gallery
                        ) );
                    }



                    //$attachments = array_filter( explode( ',', $product_image_gallery ) );

                    if ( $video_attachments )
                        foreach ( $video_attachments as $attachment ) {
                            echo '<li class="video" data-attachment_id="' . $attachment->id . '">
                                Format: ' . $attachment->post_mime_type . '
                                <ul class="actions">
                                    <li><a href="#" class="delete" title="' . esc_html__( 'Delete image', 'woopress-core' ) . '">' . esc_html__( 'Delete', 'woopress-core' ) . '</a></li>
                                </ul>
                            </li>';
                        }
                ?>
            </ul>

            <input type="hidden" id="product_video_gallery" name="product_video_gallery" value="<?php echo esc_attr( $product_image_gallery ); ?>" />

        </div>
        <p class="add_product_video hide-if-no-js">
            <a href="#"><?php esc_html_e( 'Add product gallery video', 'woopress-core' ); ?></a>
        </p>
        <p>
            <?php esc_html_e('Or you can use YouTube or Vimeo iframe code', 'woopress-core'); ?>
        </p>
        <div class="product_iframe_video">

            <textarea name="et_video_code" id="et_video_code" rows="7"><?php echo esc_attr( $product_video_code ); ?></textarea>

        </div>
        <script type="text/javascript">
            jQuery(document).ready(function($){

                // Uploading files
                var product_gallery_frame;
                var $image_gallery_ids = $('#product_video_gallery');
                var $product_images = $('#product_video_container ul.product_video');

                jQuery('.add_product_video').on( 'click', 'a', function( event ) {

                    var $el = $(this);
                    var attachment_ids = $image_gallery_ids.val();

                    event.preventDefault();

                    // If the media frame already exists, reopen it.
                    if ( product_gallery_frame ) {
                        product_gallery_frame.open();
                        return;
                    }

                    // Create the media frame.
                    product_gallery_frame = wp.media.frames.downloadable_file = wp.media({
                        // Set the title of the modal.
                        title: '<?php esc_html_e( 'Add Images to Product Gallery', 'woopress-core' ); ?>',
                        button: {
                            text: '<?php esc_html_e( 'Add to gallery', 'woopress-core' ); ?>',
                        },
                        multiple: true,
                        library : { type : 'video'}
                    });

                    // When an image is selected, run a callback.
                    product_gallery_frame.on( 'select', function() {

                        var selection = product_gallery_frame.state().get('selection');

                        selection.map( function( attachment ) {

                            attachment = attachment.toJSON();

                            if ( attachment.id ) {
                                attachment_ids = attachment_ids ? attachment_ids + "," + attachment.id : attachment.id;

                                $product_images.append('\
                                    <li class="video" data-attachment_id="' + attachment.id + '">\
                                        Video\
                                        <ul class="actions">\
                                            <li><a href="#" class="delete" title="<?php _e( 'Delete video', 'woopress-core' ); ?>"><?php _e( 'Delete', 'woopress-core' ); ?></a></li>\
                                        </ul>\
                                    </li>');
                            }

                        } );

                        $image_gallery_ids.val( attachment_ids );
                    });

                    // Finally, open the modal.
                    product_gallery_frame.open();
                });

                // Image ordering
                $product_images.sortable({
                    items: 'li.video',
                    cursor: 'move',
                    scrollSensitivity:40,
                    forcePlaceholderSize: true,
                    forceHelperSize: false,
                    helper: 'clone',
                    opacity: 0.65,
                    placeholder: 'wc-metabox-sortable-placeholder',
                    start:function(event,ui){
                        ui.item.css('background-color','#f6f6f6');
                    },
                    stop:function(event,ui){
                        ui.item.removeAttr('style');
                    },
                    update: function(event, ui) {
                        var attachment_ids = '';

                        $('#product_video_container ul li.video').css('cursor','default').each(function() {
                            var attachment_id = jQuery(this).attr( 'data-attachment_id' );
                            attachment_ids = attachment_ids + attachment_id + ',';
                        });

                        $image_gallery_ids.val( attachment_ids );
                    }
                });

                // Remove images
                $('#product_video_container').on( 'click', 'a.delete', function() {

                    $(this).closest('li.video').remove();

                    var attachment_ids = '';

                    $('#product_video_container ul li.video').css('cursor','default').each(function() {
                        var attachment_id = jQuery(this).attr( 'data-attachment_id' );
                        attachment_ids = attachment_ids + attachment_id + ',';
                    });

                    $image_gallery_ids.val( attachment_ids );

                    return false;
                } );

            });
        </script>
        <?php
    }
}

add_action( 'woocommerce_process_product_meta', 'et_save_video_meta' );

if(!function_exists('et_save_video_meta')) {
    function et_save_video_meta($post_id) {
        // Gallery Images
        $video_ids =  explode( ',',  $_POST['product_video_gallery']  ) ;
        update_post_meta( $post_id, '_product_video_gallery', implode( ',', $video_ids ) );
        update_post_meta( $post_id, '_product_video_code',  $_POST['et_video_code']  );
    }
}