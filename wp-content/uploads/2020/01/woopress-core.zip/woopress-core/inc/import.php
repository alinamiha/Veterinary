<?php

/**
 * ETheme Import.
 *
 * Import base demo content ant theme versions.
 *
 * @since   1.1.0
 * @version 1.0.0
 */
if( ! class_exists( 'ETheme_Import' ) ) {
    class ETheme_Import{
    	
        // ! Main construct/ add actions
    	public function __construct(){
    		add_action( 'wp_ajax_etheme_import_ajax', array($this, 'etheme_import_data' ) );
    		add_action( 'wp_ajax_etheme_install_version', array( $this, 'etheme_install_version' ) );
    	}

        /**
         * Update pages.
         *
         * @since   1.1.0
         * @version 1.0.0
         * @param   {array} $args - array of page ids
         */
        public function update_pages( $args = array() ){
            update_option( 'show_on_front', 'page' );

            if ( isset( $args['home_id'] ) ) {
                update_option( 'page_on_front', $args['home_id'] );
            }

            if ( isset( $args['blog_id'] ) ) {
                update_option( 'page_for_posts', $args['blog_id'] );
            }
        }

        /**
         * Update theme options.
         *
         * @since   1.1.0
         * @version 1.0.0
         * @param   {string} $file - path to file with options
         */
        public function update_theme_options( $file ){
            if( ! class_exists( 'ReduxFrameworkInstances' ) ) return;

            global $woopress_redux_options;

            $new_options = wp_remote_get( $file );
            $new_options = json_decode( $new_options['body'], true );

            // $default_options = require apply_filters('etheme_file_url', ETHEME_THEME . 'default-options.php');
            if( $new_options ) {

                //$new_options = wp_parse_args( $new_options, $default_options );
                $new_options = wp_parse_args( $new_options, $woopress_redux_options );
                $redux       = ReduxFrameworkInstances::get_instance( 'woopress_redux_options' );

                if ( isset ( $redux->validation_ran ) ) {
                    unset ( $redux->validation_ran );
                }

                $redux->set_options( $redux->_validate_options( $new_options ) );
            }
        }

        /**
         * Create tmp dir.
         *
         * @since   1.1.0
         * @version 1.0.0
         */
        public function tmp_dir(){
            if ( ! is_dir( PARENT_DIR.'/framework/tmp' ) ) {
                mkdir( PARENT_DIR.'/framework/tmp', 0777 );
            }
        }

        /**
         * Import sliders
         *
         * @since   1.1.0
         * @version 1.0.0
         * @param   {string} $sliderZip - path to file with slider
         */
        public function slider( $sliderZip ){
            $sldier_content = $this->et_get_remote_content($sliderZip);

            if( $sldier_content && class_exists( 'RevSlider' ) ) {
                $tmpZip = PARENT_DIR.'/framework/tmp/tempSliderZip.zip';

                file_put_contents($tmpZip, $sldier_content);

                $revapi = new RevSlider();

                $_FILES["import_file"]["tmp_name"] = $tmpZip;

                ob_start();

                $slider_result = $revapi->importSliderFromPost();

                ob_end_clean();
            }
        }

        /**
         * Import data from xml file
         *
         * @since   1.1.0
         * @version 1.0.0
         * @param   {string} $file - path to xml file
         */
        public function import_xml($file=false){
            ini_set( 'max_execution_time', '9000' );
            if ( ! defined( 'WP_LOAD_IMPORTERS' ) ) {
                define( 'WP_LOAD_IMPORTERS' , true );
            }

            include 'wordpress-importer/wordpress-importer.php';


            //Load Importer API
            require_once ABSPATH . 'wp-admin/includes/import.php';
            $importerError = false;

            //check if wp_importer, the base importer class is available, otherwise include it
            if ( !class_exists( 'WP_Importer' ) ) {
                $class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
                if ( file_exists( $class_wp_importer ) )
                    require_once($class_wp_importer);
                else
                    $importerError = true;
            }

            if($importerError !== false) {
                echo ("The Auto importing script could not be loaded. Please use the wordpress importer and import the XML file that is located in your themes folder manually.");
            } else {

                do_action('et_before_data_import');

                if(class_exists('WP_Importer')){
                    try{
                       ob_start();
                            add_filter( 'intermediate_image_sizes', array( $this, 'sizes_array') );
                            $importer = new WP_Import();
                            $importer->fetch_attachments = true;
                            $importer->import($file);
                        ob_get_clean();
                    } catch (Exception $e) {
                        echo ("Error while importing");
                    }

                }

            }
        }

        /**
         * Import base demo content
         *
         * @since   1.1.0
         * @version 1.0.0
         */
    	public function etheme_import_data() {

            ini_set( 'max_execution_time', '9000' );

            $demo_data_installed = get_option( 'demo_data_installed' );
    	    if( $demo_data_installed == 'yes' ) die();

            $this->tmp_dir();


            $file = get_template_directory() ."/framework/dummy/Dummy.xml";

            $this->import_xml($file);

            $versionsUrl = 'http://8theme.com/import/' . ETHEME_DOMAIN . '_versions/';
            $ver = 'default';
            $folder = $versionsUrl.''.$ver;

    	    
            $this->slider( $folder.'/slider.zip' );
            $this->update_theme_options($folder.'/options.json');

            $home_id = get_page_by_title('Home');
            $blog_id = get_page_by_title('Blog');

            $this->update_pages( array( 'home_id' => $home_id->ID, 'blog_id' => $blog_id->ID ) );

            $this->etheme_update_menus();
            $this->et_update_widgets('ecommerce');

    		
            add_option('demo_data_installed', 'yes');


    		die();
    	}

        /**
         * Import theme versions
         *
         * @since   1.1.0
         * @version 1.0.0
         */
    	public function etheme_install_version() {

    		if( empty($_POST['ver']) ) die();


    		$this->tmp_dir();

            $output = '';
    		$versionsUrl = 'http://8theme.com/import/' . ETHEME_DOMAIN . '_versions/' ;
    		$ver = $_POST['ver'];
    		$folder = $versionsUrl.''.$ver;


            $this->slider( $folder.'/slider.zip' );
            $this->slider( $folder.'/slider2.zip' );
    		$this->slider( $folder.'/slider3.zip' );


    		$version_xml = $folder.'/version_data.xml';
    		$version_content = $this->et_get_remote_content($version_xml);
    		$type_gz = false;

    		if ( ! $version_content ) {
    			$version_xml = $folder.'/version_data.xml.gz';
    			$version_content = $this->et_get_remote_content($version_xml);
    			$type_gz = true;
    		}

    		if($version_content) {

    			if ($type_gz) {
    				$tmpxml = PARENT_DIR.'/framework/tmp/version_data.xml.gz';
    			} else {
    				$tmpxml = PARENT_DIR.'/framework/tmp/version_data.xml';
    			}

    			file_put_contents($tmpxml, $version_content);

    			//check if wp_importer, the base importer class is available, otherwise include it
    			if ( !class_exists( 'WP_Importer' ) ) {
    				$class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
    				if ( file_exists( $class_wp_importer ) )
    					require_once($class_wp_importer);
    				else
    					$importerError = true;
    			}


                $this->import_xml($tmpxml);

                $home_page = get_page_by_title( 'Home ' . $ver );
                $this->update_pages( array( 'home_id' => $home_page->ID ) );
  
                $output .= '<div class="updated">';
                    $output .= "Version page installed successfully!";
                $output .= "</div>";

    		}

    		$this->update_theme_options($folder.'/options.json');

    		$widgets_array = require apply_filters('et_file_url', PARENT_DIR . '/framework/widgets-import.php');
    		if ( array_key_exists($ver, $widgets_array) ) {
    			$this->et_update_widgets($ver);
    			$output .= '<div class="updated">';
    				$output .= "Widgets updated!";
    			$output .= "</div>";
    		}

    		die($output);
    	}

        /**
         * Update menus
         *
         * @since   1.1.0
         * @version 1.0.0
         */
        public function etheme_update_menus(){

            global $wpdb;

            $menuname = 'main menu';
            $bpmenulocation = 'main-menu';
            $mobilemenulocation = 'mobile-menu';

            $tablename = $wpdb->prefix.'terms';
            $menu_ids = $wpdb->get_results(
                "
                SELECT term_id
                FROM ".$tablename."
                WHERE name= '".$menuname."'
                "
            );

            // results in array
            foreach($menu_ids as $menu):
                $menu_id = $menu->term_id;
            endforeach;

            if( !has_nav_menu( $bpmenulocation ) ){
                $locations = get_theme_mod('nav_menu_locations');
                $locations[$bpmenulocation] = $menu_id;
                $locations[$mobilemenulocation] = $menu_id;
                set_theme_mod( 'nav_menu_locations', $locations );
            }
        }

        /**
         * Get remote content
         *
         * @since   1.1.0
         * @version 1.0.0
         */
        public function et_get_remote_content($url) {

            $response = wp_remote_get($url);

            if( is_array($response) && $response['response']['code'] !== 404 ) {
                $header = $response['headers']; // array of http header lines
                $body = $response['body']; // use the content
                return $body;
            }

            return false;
        }

        /**
         * Import theme widgets
         *
         * @since   1.1.0
         * @version 1.0.0
         * @param   {string} $version - version name
         */
        public function et_update_widgets($version){

            $widgets = require apply_filters('et_file_url', PARENT_DIR . '/framework/widgets-import.php');

            $active_widgets = get_option( 'sidebars_widgets' );
            $widgets_counter = 1;

            foreach ($widgets[$version] as $area => $params) {

                if (! empty( $active_widgets[$area] ) && $params['flush']) {
                    unset($active_widgets[ $area ]);
                }

                foreach ($params['widgets'] as $widget => $args) {

                    if ( $widget == 'etheme-static-block' && !empty( $args['block_title'] ) ) {
                        $sb = et_get_static_blocks();
                        $val = array();

                        $search_value = $args['block_title'];
                        try{
                            foreach ($sb as $key => $value) {
                                if( is_array($value) ){
                                    array_walk_recursive( $value, function($v, $k) use($search_value ,$key,$value,&$val ){
                                        if( strpos($v, $search_value ) !== false ) $val[$key] = $value;
                                    });
                                }else{
                                    if( strpos( $value, $search_value ) !== false ) $val[$key] = $value;
                                }
                            }
                        }catch (Exception $e) {
                            return false;
                        }
                        $block_values = $val;
                        if ( ! empty($block_values) ) {
                            $block_values = array_values($block_values);
                            $args['block_id'] = $block_values[0]['value'];
                            unset( $args['block_title'] );
                        }
                    }

                    $active_widgets[ $area ][] = $widget . '-' . $widgets_counter;
                    $widget_content = get_option( 'widget_' . $widget );
                    $widget_content[ $widgets_counter ] = $args;
                    update_option(  'widget_' . $widget, $widget_content );
                    $widgets_counter ++;
                }
            }
            update_option( 'sidebars_widgets', $active_widgets );
        }
    }
}

new ETheme_Import();