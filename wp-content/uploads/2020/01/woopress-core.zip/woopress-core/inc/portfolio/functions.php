<?php

/**
*
* Portfolio
*
*/




add_shortcode('portfolio', 'etheme_portfolio_shortcode');

function etheme_portfolio_shortcode($atts) {
	$a = shortcode_atts( array(
       'title' => 'Recent Works',
       'limit' => 12
   ), $atts );


   return etheme_get_recent_portfolio($a['limit'], $a['title']);

}


function etheme_get_recent_portfolio($limit, $title = 'Recent Works', $not_in = 0) {
	$args = array(
		'post_type' => 'etheme_portfolio',
		'order' => 'DESC',
		'orderby' => 'date',
		'posts_per_page' => $limit,
		'post__not_in' => array( $not_in )
	);

	return etheme_create_portfolio_slider($args, $title);
}

function etheme_create_portfolio_slider($args,$title = false,$width = 540, $height = 340, $crop = true){
	global $wpdb;
    $box_id = rand(1000,10000);
    $multislides = new WP_Query( $args );
    $sliderHeight = etheme_get_option('default_blog_slider_height');
    $class = '';

	ob_start();
        if ( $multislides->have_posts() ) :
            $title_output = '';
            if ($title) {
                $title_output = '<h3 class="title"><span>'.$title.'</span></h3>';
            }
              echo '<div class="slider-container carousel-area '.$class.'">';
	              echo $title_output;
	              echo '<div class="items-slide slider-'.$box_id.'">';
	                    echo '<div class="owl-carousel slider recentCarousel">';
	                    $_i=0;
	                    while ($multislides->have_posts()) : $multislides->the_post();
	                        $_i++;
	                        get_template_part( 'portfolio', 'slide' );

	                    endwhile;
	                    echo '</div><!-- slider -->';
	              echo '</div><!-- products-slider -->';
              echo '</div><!-- slider-container -->';


			  echo '
                  <script type="text/javascript">
  	               	jQuery(".slider-'.$box_id.' .slider").owlCarousel({
  			            items : 4,
  			            lazyLoad: true,
  			            nav: true,
  			            navText: ["",""],
  			            rewind: false,
  			            responsive: {
  			                0: {
  			                    items: 1
  			                },
  			                479: {
  			                    items: 2
  			                },
  			                619: {
  			                    items: 2
  			                },
  			                768: {
  			                    items: 2
  			                },
  			                1200: {
  			                    items: 3
  			                },
  			                1600: {
  			                    items: 3
  			                }
  			            }
  			        });

                  </script>
              ';
        endif;
        wp_reset_query();

	$html = ob_get_contents();
	ob_end_clean();

	return $html;
}


function etheme_portfolio_pagination($wp_query, $paged, $pages = '', $range = 2) {
     $showitems = ($range * 2)+1;

     if(empty($paged)) $paged = 1;

     if($pages == '')
     {
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }

     if(1 != $pages)
     {
         echo "<nav class='pagination-cubic portfolio-pagination'>";
	         echo '<ul class="page-numbers">';
		         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<li><a href='".get_pagenum_link(1)."' class='prev page-numbers'><i class='fa fa-angle-double-left'></i></a></li>";

		         for ($i=1; $i <= $pages; $i++)
		         {
		             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
		             {
		                 echo ($paged == $i)? "<li><span class='page-numbers current'>".$i."</span></li>":"<li><a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a></li>";
		             }
		         }

		         if ($paged < $pages && $showitems < $pages) echo "<li><a href='".get_pagenum_link($paged + 1)."' class='next page-numbers'><i class='fa fa-angle-double-right'></i></a></li>";
	         echo '</ul>';
         echo "</nav>\n";
     }
}

function print_item_cats($id) {

	//Returns Array of Term Names for "categories"
	$term_list = wp_get_post_terms($id, 'portfolio_category');
	$_i = 0;
	foreach ($term_list as $value) {
		$_i++;
                echo '<a href="'.get_term_link($value).'">';
		echo $value->name;
                echo '</a>';
		if($_i != count($term_list))
			echo ', ';
	}
}



add_shortcode('portfolio_grid', 'etheme_portfolio_grid_shortcode');

function etheme_portfolio_grid_shortcode() {
	$a = shortcode_atts( array(
       'categories' => '',
       'limit' => -1,
   		'show_pagination' => 1
   ), $atts );


   return get_etheme_portfolio($a['categories'], $a['limit'], $a['show_pagination']);

}




function get_etheme_portfolio($categories = false, $limit = false, $show_pagination = true) {

		$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		$cat = get_query_var('portfolio_category');

		$tax_query = array();

		if(!$limit) {
			$limit = etheme_get_option('portfolio_count');
		}

		if(is_array($categories) && !empty($categories)) {
			$tax_query = array(
				array(
					'taxonomy' => 'portfolio_category',
					'field' => 'id',
					'terms' => $categories,
					'operator' => 'IN'
				)
			);
		} else if(!empty($cat)) {
			$tax_query = array(
				array(
					'taxonomy' => 'portfolio_category',
					'field' => 'slug',
					'terms' => $cat
				)
			);
		}

		$args = array(
			'post_type' => 'etheme_portfolio',
			'paged' => $paged,
			'posts_per_page' => $limit,
			'tax_query' => $tax_query
		);

		$loop = new WP_Query($args);

		if ( $loop->have_posts() ) : ?>
			<div>
				<ul class="portfolio-filters">
					<li>
						<a
							href="#"
							data-filter="*"
							class="btn big <?php echo ( !isset($_GET['et-cat']) ) ? 'active' : ''; ?>"
						>
						<?php echo ( get_query_var('portfolio_category') ) ? get_query_var('portfolio_category') : esc_html__('Show All', 'woopress-core'); ?>
						</a>
					</li>
						<?php
						$categories = get_terms('portfolio_category', array('include' => $categories));
						$catsCount = count($categories);
						$_i=0;

						if ( get_query_var('portfolio_category') ) {
							$queried_object = get_queried_object();
							$term_id = $queried_object->term_id;
							$_terms = array();
							$categories = get_term_children( $term_id, 'portfolio_category' );
							foreach ($categories as $key) {
								$_terms[] = get_term( $key, 'portfolio_category' );
							}
							$categories = $_terms;
						}

						foreach($categories as $category) {
							$_i++;
							?>
								<li>
									<a
										href="#"
										data-filter=".sort-<?php echo $category->slug; ?>"
										class="btn big <?php echo ( isset($_GET['et-cat']) && $_GET['et-cat'] == $category->term_id ) ? 'active' : ''; ?>"
									>
										<?php echo $category->name; ?>
									</a>
								</li>
							<?php
						}

						?>
				</ul>

				<div class="row portfolio masonry">
				<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

					<?php
						get_template_part( 'content', 'portfolio' );
					?>

				<?php endwhile; ?>
				</div>
			</div>

		<?php if ($show_pagination): ?>
			<?php etheme_portfolio_pagination($loop, $paged); ?>
		<?php endif ?>

		<?php wp_reset_query(); ?>

	<?php else: ?>

		<h3><?php esc_html_e('No projects were found!', 'woopress-core') ?></h3>

	<?php endif;
}
