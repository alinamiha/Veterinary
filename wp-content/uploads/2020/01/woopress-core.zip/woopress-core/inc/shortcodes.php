<?php

add_action( 'init', 'woopress_shortcodes_init');

if ( ! function_exists( 'woopress_shortcodes_init' ) ) :
    function woopress_shortcodes_init(){

        $shortcodes_default = array(
            'block'       => 'etheme_block_shortcode',
            'et_top_cart' => 'et_top_cart_shortcode',
            'et_menu'     => 'et_menu_shortcode',
            'etheme_products'  => 'etheme_products_shortcodes',
        );

        foreach ( $shortcodes_default as $key => $value ) {
            $file = trailingslashit( WOOPRESS_CORE_DIR . 'inc/shortcodes/' )  . $key . '.php';
            if( file_exists( $file ) ) {
                add_shortcode( $key, $value );
                require_once( $file );
            }
        }

        if ( ! function_exists( 'vc_map' ) ) {
            return;
        }
        $shortcodes = array(
            'alert'                     => 'etheme_alert_shortcode',
            'banner'                    => 'etheme_banner_shortcode',
            'blockquote'                => 'etheme_blockquote_shortcode',
            'brands'                    => 'et_brands',
            'button'                    => 'etheme_btn_shortcode',
            'callto'                    => 'etheme_callto_shortcode',
            'checklist'                 => 'etheme_checklist_shortcode',
            'column'                    => 'etheme_column_shortcode',
            'contact_form'              => 'et_contact_form',
            'countdown'                 => 'etheme_countdown_shortcode',
            'counter'                   => 'etheme_counter_shortcode',
            'dropcap'                   => 'etheme_dropcap_shortcode',
            'et_section'                => 'etheme_et_section_shortcode',
            'etheme_featured'           => 'etheme_featured_shortcodes',
            'etheme_new'                => 'etheme_new_shortcodes',
            'etheme_product_categories' => 'etheme_product_categories',
            'etheme_search'             => 'etheme_search',
            'follow'                    => 'et_follow_shortcode',
            'gallery'                   => 'etheme_gallery_shortcode',
            'googlechart'               => 'etheme_googlechart_shortcode',
            'googlefont'                => 'etheme_googlefont_shortcode',
            'hr'                        => 'etheme_hr_shortcode',
            'icon'                      => 'etheme_icon_shortcode',
            'icon_box'                  => 'etheme_icon_box_shortcode',
            'image'                     => 'etheme_image_shortcode',
            'et_instagram'              => 'etheme_instagram_shortcode',
            'et_links'                  => 'et_links_shortcode',
            'ptable'                    => 'etheme_ptable_shortcode',
            'progress'                  => 'etheme_progress_shortcode',
            'et_promo'                  => 'et_promo_shortcode',
            'project_links'             => 'etheme_project_links',
            'qrcode'                    => 'etheme_qrcode_shortcode',
            'quick_view'                => 'etheme_quick_view_shortcodes',
            'et_recent_comments'        => 'etheme_recent_comments_shortcode',
            'recent_posts'              => 'etheme_recent_posts_shortcode',
            'et_recent_posts_widget'    => 'etheme_recent_posts_widget_shortcode',
            'row'                       => 'etheme_row_shortcode',
            'et_top_search'             => 'et_top_search_shortcode',
            'share'                     => 'etheme_share_shortcode',
            'single_post'               => 'etheme_featured_post_shortcode',
            'tab'                       => 'etheme_tab_shortcode',
            'tabs'                      => 'etheme_tabs_shortcode',
            'team_member'               => 'etheme_team_member_shortcode',
            'teaser_box'                => 'etheme_teaser_box_shortcodes',
            'title'                     => 'etheme_title_shortcode',
            'toggle'                    => 'etheme_toggle_shortcode',
            'toggle_block'              => 'etheme_toggle_block_shortcode',
            'tooltip'                   => 'etheme_tooltip_shortcode',
            'twitter_slider'            => 'et_twitter_slider',
            'vimeo'                     => 'etheme_vimeo_shortcode',
            'youtube'                   => 'etheme_youtube_shortcode',
            'template_url'              => 'etheme_template_url_shortcode',
            'base_url'                  => 'etheme_base_url_shortcode'
        );
    foreach ( $shortcodes as $key => $value ) {
        $file = trailingslashit( WOOPRESS_CORE_DIR . 'inc/shortcodes/' )  . $key . '.php';
        if( file_exists( $file ) ) {
            add_shortcode( $key, $value );
            require_once( $file );
        }
    }

    $file = trailingslashit( WOOPRESS_CORE_DIR . 'inc/shortcodes/' )  . 'testimonials.php';
    require_once( $file );
}
endif;