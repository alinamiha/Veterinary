<?php
/*
Plugin Name: Woopress Core
Plugin URI: http://8theme.com
Description: Woopress Core Plugin for woopress theme
Version: 1.1.1
Author: 8theme
Text Domain: woopress-core
Author URI: http://8theme.com
*/

if( !defined( 'WPINC' ) ) die();


/**
 * Load plugin compatibility.
 * 
 * @since 1.1.0
 */
include 'inc/plugin-compatibility.php';

if ( ! woopress_plugin_compatibility() ) {
    return;
}

/**
 * define ET_CORE_DIR.
 * 
 * @since 1.1.0
 */
define( 'WOOPRESS_CORE_DIR', plugin_dir_path( __FILE__ ) );


/**
 * define WOOPRESS_CORE_URL.
 * 
 * @since 1.0.0
 * @version 1.0.0
 */
define( 'WOOPRESS_CORE_URL', plugin_dir_url( __FILE__ ) );

/**
 * Load plugin widgets.
 * 
 * @since 1.0.0
 * @version 1.0.0
 */
include 'inc/widgets.php';

/**
 * Load post-type testimonials.
 * Do it to prevent errors with old 8theme themes
 * @since 1.0.0
 * @version 1.0.0
 */
include 'inc/testimonials/woothemes-testimonials.php';

/**
 * Load post-type portfolio.
 * 
 * @since 1.0.0
 * @version 1.0.0
 */
include 'inc/portfolio/portfolio.php';
include 'inc/portfolio/functions.php';

/**
 * Load post-type brands.
 * 
 * @since 1.0.0
 * @version 1.0.0
 */
include 'inc/brands/brands.php';

/**
 * Load post-type staticblocks.
 * 
 * @since 1.0.0
 * @version 1.0.0
 */
include 'inc/staticblocks/staticblocks.php';

/**
 * Load shortcodes.
 * 
 * @since 1.1.0
 */
include 'inc/shortcodes.php';


/**
 * 
 * 
 * @since 1.1.0
 */
include 'inc/import.php';


/**
 * 
 * 
 * @since 1.1.0
 */
include 'inc/twitteroauth/twitteroauth.php';


/**
 * 
 * 
 * @since 1.1.0
 */
include 'inc/custom-metaboxes.php';


/**
 * 
 * 
 * @since 1.1.0
 */
include 'inc/functions.php';

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @version 1.0.0
 */
add_action( 'plugins_loaded', 'woopress_core_load_textdomain' );
function woopress_core_load_textdomain() {
    $locale = apply_filters( 'plugin_locale', get_locale(), 'woopress-core' );

    load_textdomain( 'woopress-core', WP_LANG_DIR . '/woopress-core/woopress-core-' . $locale . '.mo' );
    load_plugin_textdomain( 'woopress-core', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );

    add_filter( 'pre_set_site_transient_update_plugins', 'check_for_plugin_update_woopress');
}


/**
 * Check for plugin update
 *
 * @since 1.0.0
 * @version 1.0.0
 */
function check_for_plugin_update_woopress($checked_data){
    if ( ! defined( 'ETHEME_API' ) ) return $checked_data;

    $update_info    = get_option( 'etheme-update-info', false );
    $key            = get_option('etheme_api_key', false);
    if ( !$key || $key == '' ) {
        $key = get_option( 'etheme_activated_data' );
        if ( is_array( $key ) && isset( $key['api_key'] ) ) {
            $key = $key['api_key'];
        }
    }
    $plugins_dir    = ETHEME_API . 'files/get/';
    $token          = '?token=' . $key;
    $plugin_ver     = ( isset( $update_info->plugin_version ) && ! empty( $update_info->plugin_version ) ) ? $update_info->plugin_version : false;

    if ( version_compare( '1.1.1', $plugin_ver, '<' ) ) {
        $plugins_dir = ETHEME_API . 'files/get/';
        $plugins_dir . 'woopress-core.zip';

        $plugin = new stdClass();
        $plugin->slug = 'woopress-core';
        $plugin->plugin = 'woopress-core/woopress-core.php';
        $plugin->new_version = $plugin_ver;
        $plugin->url = 'https://8theme.com/demo/woopress/woopress-core/change-log.txt';
        $plugin->package = $plugins_dir . 'woopress-core.zip' . $token;
        $plugin->tested = '5.0';
        $checked_data->response['woopress-core/woopress-core.php'] = $plugin;
    }

    return $checked_data;
}